# Vivilo Android

Android media application built with Kotlin, Jetpack Compose and Gradle.

## Automated APK builds

GitHub Actions runs tests and builds a debug-signed installable APK on pushes,
pull requests, and manual workflow dispatches.

1. Create a **public** GitHub repository named `Vivilo` under `bruce-Bana`.
2. Upload/push the contents of this folder to the repository root (not the ZIP file itself).
3. Open **Actions** and enable workflows if GitHub prompts you.
4. Open the latest **Build Vivilo Android APK** run. Download the
   `vivilo-android-apk` artifact to get `vivilo.apk`.
5. To publish a permanent download link, create and push a version tag:
   `git tag v1.0.0 && git push origin v1.0.0`.
   The workflow publishes `vivilo.apk` to the GitHub Release.

## Website download URL

After the repository exists and the first tag/release succeeds, use:

`https://github.com/bruce-Bana/Vivilo/releases/latest/download/vivilo.apk`

The matching checksum is:

`https://github.com/bruce-Bana/Vivilo/releases/latest/download/vivilo.apk.sha256`

## Build configuration notes

- The supplied source declares Android Gradle Plugin `9.1.1`.
- AGP 9.1 requires Gradle `9.3.1`; the workflow provisions that exact Gradle version.
- The supplied ZIP does not contain Gradle Wrapper scripts or wrapper JAR, so the
  workflow uses the official Gradle setup action to install Gradle and invokes
  `gradle` directly. This avoids committing a partial/broken wrapper.
- The workflow builds `debug`, which is signed with Android's standard debug key
  and can be installed for testing. It is not a Play Store production-signed build.
- Release signing is intentionally not configured because no upload keystore or
  signing credentials were supplied. Do not commit signing keys or passwords.
- If the build fails, inspect the Actions job log; dependency or source errors
  must be fixed before claiming the APK is ready.

## Local build

With JDK 17, Android SDK and Gradle 9.3.1 installed:

```bash
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
