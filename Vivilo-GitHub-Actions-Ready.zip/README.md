# Vivilo Android app

This repository contains the Android project from `vivilo.zip` plus a GitHub Actions pipeline.

## CI build

- Runs on pushes to `main`/`master`, pull requests, and manual dispatch.
- Uses JDK 17, Gradle 9.3.1, and Android SDK platform `android-36-ext1`.
- Runs `:app:testDebugUnitTest` and `:app:assembleDebug`.
- Uploads `vivilo.apk` and its SHA-256 checksum as the `vivilo-android-apk` Actions artifact.

## Installable APK

The debug APK is signed with Android's standard debug key and is suitable for testing/installing. It is not a Play Store production-signed release.

To publish a versioned GitHub Release, push a tag such as `v1.0.0`. The workflow publishes `vivilo.apk` and `vivilo.apk.sha256`.

## App details

- Application ID: `com.vivilo.media`
- Minimum Android version: API 24 (Android 7.0)
- Compile SDK: Android 36 extension 1
- Main stack: Kotlin, Jetpack Compose, Room, Media3/ExoPlayer

## Local build

Install Android Studio/Android SDK and Gradle 9.3.1, then run:

```bash
gradle :app:testDebugUnitTest :app:assembleDebug
```

The output APK is under `app/build/outputs/apk/debug/`.
