package com.vivilo.media

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.Coil
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import com.vivilo.media.ui.screens.BrowserScreen
import com.vivilo.media.ui.screens.PlayerScreen
import com.vivilo.media.ui.theme.ViviloTheme
import com.vivilo.media.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val sharedViewModel: MainViewModel by viewModels()

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Pressing Home while a video is on screen keeps it playing in a floating window.
        val pm = com.vivilo.media.service.PlaybackManager.getInstance(this)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O &&
            pm.videoScreenVisible && pm.isPlaying.value
        ) {
            runCatching {
                enterPictureInPictureMode(
                    android.app.PictureInPictureParams.Builder()
                        .setAspectRatio(android.util.Rational(16, 9))
                        .build()
                )
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Backgrounding the app re-locks the Safe folder and wipes decrypted temp copies.
        if (!isChangingConfigurations && !(android.os.Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode)) sharedViewModel.lockSafeFolder()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val imageLoader = ImageLoader.Builder(this)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .build()
        Coil.setImageLoader(imageLoader)

        enableEdgeToEdge()
        setContent {
            ViviloTheme {
                val navController = rememberNavController()
                val mainViewModel: MainViewModel = viewModel()

                NavHost(
                    navController = navController,
                    startDestination = "browser",
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable("browser") {
                        BrowserScreen(
                            viewModel = mainViewModel,
                            onNavigateToPlayer = { mediaFile ->
                                val uriEncoded = Uri.encode(mediaFile.uri.toString())
                                navController.navigate("player/$uriEncoded")
                            }
                        )
                    }
                    composable(
                        "player/{uri}",
                        arguments = listOf(navArgument("uri") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val uriString = backStackEntry.arguments?.getString("uri") ?: ""
                        PlayerScreen(
                            uriString = uriString,
                            viewModel = mainViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
