package com.vivilo.media.data

import android.net.Uri

data class MediaFile(
    val id: Long,
    val uri: Uri,
    val name: String,
    val duration: Long,
    val size: Long,
    val mimeType: String,
    val dateAdded: Long,
    val isVideo: Boolean,
    val isAudio: Boolean,
    val isImage: Boolean,
    val isDocument: Boolean,
    val isDirectory: Boolean = false,
    val absolutePath: String? = null
)
