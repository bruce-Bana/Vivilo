package com.vivilo.media.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaRepository(private val context: Context) {

    private enum class Kind { VIDEO, AUDIO, IMAGE }

    suspend fun getMediaFiles(): List<MediaFile> = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mediaList = ArrayList<MediaFile>()

        mediaList += queryMedia(resolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, Kind.VIDEO)
        mediaList += queryMedia(resolver, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, Kind.AUDIO)
        mediaList += queryMedia(resolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Kind.IMAGE)
        mediaList += queryDocuments(resolver)

        mediaList.distinctBy { it.uri.toString() }.sortedByDescending { it.dateAdded }
    }

    /** Video, audio and image rows share the same column names, so one query covers all three. */
    private fun queryMedia(resolver: ContentResolver, collection: Uri, kind: Kind): List<MediaFile> {
        val hasDuration = kind != Kind.IMAGE
        val projection = buildList {
            add(MediaStore.MediaColumns._ID)
            add(MediaStore.MediaColumns.DISPLAY_NAME)
            add(MediaStore.MediaColumns.SIZE)
            add(MediaStore.MediaColumns.MIME_TYPE)
            add(MediaStore.MediaColumns.DATE_ADDED)
            if (hasDuration) add(MediaStore.MediaColumns.DURATION)
        }.toTypedArray()

        val defaultMime = when (kind) {
            Kind.VIDEO -> "video/mp4"
            Kind.AUDIO -> "audio/mpeg"
            Kind.IMAGE -> "image/jpeg"
        }

        val result = ArrayList<MediaFile>()
        try {
            resolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val durationCol = if (hasDuration) cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION) else -1

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    result += MediaFile(
                        id = id,
                        uri = ContentUris.withAppendedId(collection, id),
                        name = cursor.getString(nameCol) ?: "Unknown",
                        duration = if (durationCol >= 0) cursor.getLong(durationCol) else 0L,
                        size = cursor.getLong(sizeCol),
                        mimeType = cursor.getString(mimeCol) ?: defaultMime,
                        dateAdded = cursor.getLong(dateCol),
                        isVideo = kind == Kind.VIDEO,
                        isAudio = kind == Kind.AUDIO,
                        isImage = kind == Kind.IMAGE,
                        isDocument = false
                    )
                }
            }
        } catch (e: Exception) {
            // Missing permission or a provider hiccup must not take the whole library down.
            e.printStackTrace()
        }
        return result
    }

    /**
     * Documents live in the generic Files table, which *also* contains a row for every video,
     * song and photo. Those are already covered by the typed queries above, so only rows with
     * MEDIA_TYPE_NONE are read here. Without this filter every media file appeared twice
     * (under two different URIs) and was reported as a "duplicate" by the cleaner.
     */
    private fun queryDocuments(resolver: ContentResolver): List<MediaFile> {
        val collection = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DATE_ADDED
        )
        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE} = ?"
        val selectionArgs = arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_NONE.toString())

        val result = ArrayList<MediaFile>()
        try {
            resolver.query(
                collection,
                projection,
                selection,
                selectionArgs,
                "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED)

                while (cursor.moveToNext()) {
                    val name = cursor.getString(nameCol) ?: continue
                    val typeInfo = MimeTypeDetector.detect(name, cursor.getString(mimeCol))
                    if (!typeInfo.isDocument) continue

                    val id = cursor.getLong(idCol)
                    result += MediaFile(
                        id = id,
                        uri = ContentUris.withAppendedId(collection, id),
                        name = name,
                        duration = 0L,
                        size = cursor.getLong(sizeCol),
                        mimeType = typeInfo.mimeType,
                        dateAdded = cursor.getLong(dateCol),
                        isVideo = false,
                        isAudio = false,
                        isImage = false,
                        isDocument = true
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }

    suspend fun getStorageFiles(path: String?): List<MediaFile> = withContext(Dispatchers.IO) {
        val rootPath = path ?: android.os.Environment.getExternalStorageDirectory().absolutePath
        val directory = File(rootPath)

        if (!directory.exists() || !directory.isDirectory) return@withContext emptyList()

        val files = directory.listFiles() ?: return@withContext emptyList()

        files
            // Hidden entries (".thumbnails", ".trashed-*") are clutter in a user-facing browser.
            .filterNot { it.name.startsWith(".") }
            .map { file ->
                val typeInfo = MimeTypeDetector.detect(file.name)
                val isDir = file.isDirectory

                MediaFile(
                    id = "storage:${file.absolutePath}".hashCode().toLong(),
                    uri = Uri.fromFile(file),
                    name = file.name,
                    duration = 0,
                    size = if (isDir) 0L else file.length(),
                    mimeType = typeInfo.mimeType,
                    dateAdded = file.lastModified() / 1000,
                    isVideo = !isDir && typeInfo.isVideo,
                    isAudio = !isDir && typeInfo.isAudio,
                    isImage = !isDir && typeInfo.isImage,
                    isDocument = !isDir && typeInfo.isDocument,
                    isDirectory = isDir,
                    absolutePath = file.absolutePath
                )
            }.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }
}
