package com.vivilo.media.data

import java.util.Locale

object MimeTypeDetector {
    private val AUDIO_EXTENSIONS = setOf(
        "mp3", "wav", "flac", "aac", "m4a", "ogg", "opus", "wma", "aiff", "alac", "amr", "mid", "midi"
    )

    private val VIDEO_EXTENSIONS = setOf(
        "mp4", "mkv", "webm", "avi", "mov", "3gp", "flv", "wmv", "ts", "m4v"
    )

    private val IMAGE_EXTENSIONS = setOf(
        "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "svg"
    )

    private val DOCUMENT_EXTENSIONS = setOf(
        "pdf", "doc", "docx", "txt", "xls", "xlsx", "ppt", "pptx", "csv", "rtf", "epub", "md", "json", "xml", "log", "apk", "zip"
    )

    data class TypeInfo(
        val isAudio: Boolean,
        val isVideo: Boolean,
        val isImage: Boolean,
        val isDocument: Boolean,
        val mimeType: String
    )

    fun detect(fileName: String, rawMimeType: String? = null): TypeInfo {
        val extension = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)

        val isAudio = AUDIO_EXTENSIONS.contains(extension) || (rawMimeType?.startsWith("audio/") == true)
        val isVideo = VIDEO_EXTENSIONS.contains(extension) || (rawMimeType?.startsWith("video/") == true)
        val isImage = IMAGE_EXTENSIONS.contains(extension) || (rawMimeType?.startsWith("image/") == true)
        val isDocument = !isAudio && !isVideo && !isImage && (
            DOCUMENT_EXTENSIONS.contains(extension) ||
                rawMimeType?.contains("pdf") == true ||
                rawMimeType?.contains("document") == true ||
                rawMimeType?.contains("text") == true ||
                rawMimeType == "application/vnd.android.package-archive"
            )

        val resolvedMime = when {
            rawMimeType != null && rawMimeType != "*/*" && rawMimeType.isNotEmpty() -> rawMimeType
            isAudio -> "audio/${if (extension.isNotEmpty()) extension else "*"}"
            isVideo -> "video/${if (extension.isNotEmpty()) extension else "*"}"
            isImage -> "image/${if (extension.isNotEmpty()) extension else "*"}"
            isDocument -> when (extension) {
                "pdf" -> "application/pdf"
                "txt", "log", "md", "csv" -> "text/plain"
                "json" -> "application/json"
                "xml" -> "text/xml"
                "doc" -> "application/msword"
                "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                "xls" -> "application/vnd.ms-excel"
                "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                "ppt" -> "application/vnd.ms-powerpoint"
                "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                "apk" -> "application/vnd.android.package-archive"
                "zip" -> "application/zip"
                "epub" -> "application/epub+zip"
                else -> "application/octet-stream"
            }
            else -> "*/*"
        }

        return TypeInfo(
            isAudio = isAudio,
            isVideo = isVideo,
            isImage = isImage,
            isDocument = isDocument,
            mimeType = resolvedMime
        )
    }
}
