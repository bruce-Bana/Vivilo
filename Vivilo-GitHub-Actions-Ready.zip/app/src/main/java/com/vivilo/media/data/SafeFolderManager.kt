package com.vivilo.media.data

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.edit
import com.vivilo.media.data.db.SafeFileEntity
import com.vivilo.media.data.db.ViviloMediaDatabaseRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.InputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Outcome of moving files into the Safe folder.
 *
 * @param moved files safely copied into the vault.
 * @param failed files that could not be copied (nothing was changed for these).
 * @param originalsRemaining files that ARE in the vault but whose original copy could not be
 *        removed (Android 10+ requires the user's consent to delete files this app did not
 *        create). The user must be told, otherwise they believe the file is hidden when it isn't.
 */
data class SafeMoveResult(
    val moved: Int,
    val failed: Int,
    val originalsRemaining: Int,
    /** MediaStore URIs the user can approve deleting in one system dialog (Android 11+). */
    val pendingDeleteUris: List<Uri> = emptyList()
)

class SafeFolderManager(
    private val context: Context,
    private val dbRepository: ViviloMediaDatabaseRepository
) {
    private val prefs = context.getSharedPreferences("vivilo_safe_folder_prefs", Context.MODE_PRIVATE)
    private val vaultDir = File(context.filesDir, "safe_vault").apply { if (!exists()) mkdirs() }
    private val viewDir = File(context.cacheDir, "vault_view")

    fun isPinSet(): Boolean = prefs.contains(KEY_HASH)

    fun setPin(pin: String): Boolean {
        if (pin.length != 4 || !pin.all { it.isDigit() }) return false
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val algorithm = pbkdf2Algorithm()
        val hash = pbkdf2(pin, salt, algorithm)
        prefs.edit {
            putString(KEY_HASH, hash.toHex())
            putString(KEY_SALT, salt.toHex())
            putString(KEY_ALGO, algorithm)
            remove(KEY_FAILS)
            remove(KEY_LOCKED_UNTIL)
        }
        return true
    }

    /** Remaining lock-out in milliseconds after repeated wrong PINs; 0 when attempts are allowed. */
    fun lockoutRemainingMs(): Long {
        val until = prefs.getLong(KEY_LOCKED_UNTIL, 0L)
        return (until - System.currentTimeMillis()).coerceAtLeast(0L)
    }

    fun verifyPin(pin: String): Boolean {
        if (!isPinSet()) return false
        if (lockoutRemainingMs() > 0L) return false

        val ok = checkPin(pin)
        if (ok) {
            prefs.edit {
                remove(KEY_FAILS)
                remove(KEY_LOCKED_UNTIL)
            }
        } else {
            val fails = prefs.getInt(KEY_FAILS, 0) + 1
            prefs.edit {
                putInt(KEY_FAILS, fails)
                if (fails >= MAX_FREE_ATTEMPTS) {
                    // 30 s, 60 s, 2 min ... capped at ~32 min: makes guessing a 4-digit PIN impractical.
                    val step = (fails - MAX_FREE_ATTEMPTS).coerceAtMost(6)
                    putLong(KEY_LOCKED_UNTIL, System.currentTimeMillis() + BASE_LOCKOUT_MS * (1L shl step))
                }
            }
        }
        return ok
    }

    private fun checkPin(pin: String): Boolean {
        val savedHash = prefs.getString(KEY_HASH, null) ?: return false
        val saltHex = prefs.getString(KEY_SALT, null)

        if (saltHex == null) {
            // Legacy unsalted SHA-256 PIN from earlier builds: accept it once, then upgrade in place.
            val matches = constantTimeEquals(savedHash, legacySha256(pin))
            if (matches) setPin(pin)
            return matches
        }

        val algorithm = prefs.getString(KEY_ALGO, null) ?: pbkdf2Algorithm()
        val candidate = pbkdf2(pin, saltHex.hexToBytes(), algorithm).toHex()
        return constantTimeEquals(savedHash, candidate)
    }

    fun changePin(oldPin: String, newPin: String): Boolean {
        if (verifyPin(oldPin)) {
            return setPin(newPin)
        }
        return false
    }

    fun resetSafeFolder() {
        prefs.edit { clear() }
    }

    private fun pbkdf2Algorithm(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) "PBKDF2WithHmacSHA256" else "PBKDF2WithHmacSHA1"

    private fun pbkdf2(pin: String, salt: ByteArray, algorithm: String): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        return SecretKeyFactory.getInstance(algorithm).generateSecret(spec).encoded
    }

    private fun legacySha256(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(pin.toByteArray()).toHex()
    }

    private fun constantTimeEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun String.hexToBytes(): ByteArray =
        ByteArray(length / 2) { i -> substring(i * 2, i * 2 + 2).toInt(16).toByte() }

    suspend fun moveToSafeFolder(mediaFiles: List<MediaFile>): SafeMoveResult = withContext(Dispatchers.IO) {
        var moved = 0
        var failed = 0
        var originalsRemaining = 0
        val pendingDelete = ArrayList<Uri>()

        for (file in mediaFiles) {
            if (file.isDirectory) continue

            val vaultFileName = "vault_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.dat"
            val vaultFile = File(vaultDir, vaultFileName)

            try {
                val copiedBytes = copyIntoVault(file, vaultFile)
                if (copiedBytes < 0L || !vaultFile.exists() || (file.size > 0L && copiedBytes != file.size)) {
                    // Never touch the original unless the vault copy is verified complete.
                    vaultFile.delete()
                    failed++
                    continue
                }

                dbRepository.addSafeFile(
                    SafeFileEntity(
                        originalUriString = file.uri.toString(),
                        originalName = file.name,
                        safeVaultFileName = vaultFileName,
                        mediaType = mediaTypeOf(file),
                        duration = file.duration,
                        size = file.size
                    )
                )
                moved++

                if (!removeOriginal(file)) {
                    originalsRemaining++
                    if (file.absolutePath.isNullOrEmpty() && file.uri.scheme == "content") pendingDelete += file.uri
                }
            } catch (e: Exception) {
                e.printStackTrace()
                vaultFile.delete()
                failed++
            }
        }
        SafeMoveResult(moved, failed, originalsRemaining, pendingDelete)
    }

    /** Encrypts [file] into the vault. Returns plaintext bytes written, or -1 when it can't be opened. */
    private fun copyIntoVault(file: MediaFile, vaultFile: File): Long {
        context.contentResolver.openInputStream(file.uri)?.use { return encryptTo(it, vaultFile) }
        val path = file.absolutePath
        if (!path.isNullOrEmpty()) {
            val src = File(path)
            if (src.exists()) return src.inputStream().use { encryptTo(it, vaultFile) }
        }
        return -1L
    }

    // ---- Encryption at rest (AES-256-GCM, key held in the Android Keystore) ----

    private fun vaultKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun encryptTo(input: InputStream, vaultFile: File): Long {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, vaultKey()) }
        FileOutputStream(vaultFile).use { raw ->
            raw.write(MAGIC)
            raw.write(cipher.iv.size)
            raw.write(cipher.iv)
            CipherOutputStream(raw, cipher).use { return input.copyTo(it) }
        }
    }

    private fun isEncrypted(file: File): Boolean = try {
        FileInputStream(file).use { ins ->
            val head = ByteArray(MAGIC.size)
            ins.read(head) == MAGIC.size && head.contentEquals(MAGIC)
        }
    } catch (_: Exception) { false }

    /**
     * Returns a readable plaintext file for a vault entry (decrypted into the cache), or null if
     * it can't be read. Files stored by older builds are plaintext and returned as they are.
     */
    suspend fun decryptedFile(safeFile: SafeFileEntity): File? = withContext(Dispatchers.IO) {
        val vaultFile = File(vaultDir, safeFile.safeVaultFileName)
        if (!vaultFile.exists()) return@withContext null
        if (!isEncrypted(vaultFile)) return@withContext vaultFile

        viewDir.mkdirs()
        val ext = safeFile.originalName.substringAfterLast('.', "")
        val out = File(viewDir, safeFile.safeVaultFileName.removeSuffix(".dat") + if (ext.isNotEmpty()) ".$ext" else "")
        if (out.exists() && out.length() > 0L) return@withContext out
        try {
            FileInputStream(vaultFile).use { ins ->
                ins.skip(MAGIC.size.toLong())
                val ivLen = ins.read()
                val iv = ByteArray(ivLen).also { ins.read(it) }
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    .apply { init(Cipher.DECRYPT_MODE, vaultKey(), GCMParameterSpec(128, iv)) }
                FileOutputStream(out).use { o -> CipherInputStream(ins, cipher).copyTo(o) }
            }
            out
        } catch (e: Exception) {
            e.printStackTrace()
            out.delete()
            null
        }
    }

    /** Removes every decrypted temp copy; called whenever the Safe folder locks. */
    fun clearDecryptedCache() {
        viewDir.listFiles()?.forEach { it.delete() }
    }

    /** @return true when the original is really gone from shared storage. */
    private fun removeOriginal(file: MediaFile): Boolean {
        val path = file.absolutePath
        if (!path.isNullOrEmpty()) {
            val src = File(path)
            if (src.exists()) src.delete()
            if (!src.exists()) {
                // Keep MediaStore in sync so the file vanishes from the library immediately.
                MediaScannerConnection.scanFile(context, arrayOf(path), null, null)
                return true
            }
            return false
        }
        return try {
            context.contentResolver.delete(file.uri, null, null) > 0
        } catch (_: Exception) {
            // SecurityException/RecoverableSecurityException: needs user consent on Android 10+.
            false
        }
    }

    private fun mediaTypeOf(file: MediaFile): String = when {
        file.isImage -> "image"
        file.isVideo -> "video"
        file.isAudio -> "audio"
        file.isDocument -> "document"
        else -> "other"
    }

    suspend fun moveOutOfSafeFolder(safeFiles: List<SafeFileEntity>): Int = withContext(Dispatchers.IO) {
        var count = 0

        for (safeFile in safeFiles) {
            try {
                val vaultFile = File(vaultDir, safeFile.safeVaultFileName)
                if (!vaultFile.exists()) {
                    // Vault file is gone; drop the stale index row.
                    dbRepository.removeSafeFile(safeFile.id)
                    continue
                }
                val readable = decryptedFile(safeFile) ?: continue
                val exported = exportToPublicStorage(readable, safeFile)
                if (readable != vaultFile) readable.delete()
                if (exported) {
                    vaultFile.delete()
                    dbRepository.removeSafeFile(safeFile.id)
                    count++
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        count
    }

    /**
     * Restores a file to shared storage under a "Restored" folder. On Android 10+ this must go
     * through MediaStore: writing to Downloads/ with java.io.File fails under scoped storage,
     * which previously made "Restore" silently do nothing.
     */
    private fun exportToPublicStorage(vaultFile: File, safeFile: SafeFileEntity): Boolean {
        val detected = MimeTypeDetector.detect(safeFile.originalName)
        val mime = detected.mimeType.takeUnless { it == "*/*" } ?: "application/octet-stream"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val volume = MediaStore.VOLUME_EXTERNAL_PRIMARY
            val (collection, baseDir) = when (safeFile.mediaType) {
                "video" -> MediaStore.Video.Media.getContentUri(volume) to Environment.DIRECTORY_MOVIES
                "audio" -> MediaStore.Audio.Media.getContentUri(volume) to Environment.DIRECTORY_MUSIC
                "image" -> MediaStore.Images.Media.getContentUri(volume) to Environment.DIRECTORY_PICTURES
                else -> MediaStore.Downloads.getContentUri(volume) to Environment.DIRECTORY_DOWNLOADS
            }
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, safeFile.originalName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$baseDir/Restored")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val target = resolver.insert(collection, values) ?: return false
            return try {
                val out = resolver.openOutputStream(target) ?: throw IllegalStateException("No output stream")
                out.use { stream -> FileInputStream(vaultFile).use { it.copyTo(stream) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(target, done, null, null)
                true
            } catch (e: Exception) {
                e.printStackTrace()
                resolver.delete(target, null, null)
                false
            }
        }

        // Android 9 and below: plain file copy (WRITE_EXTERNAL_STORAGE is declared for these versions).
        @Suppress("DEPRECATION")
        val restoreDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Restored")
        if (!restoreDir.exists() && !restoreDir.mkdirs()) return false

        var destFile = File(restoreDir, safeFile.originalName)
        if (destFile.exists()) {
            val base = safeFile.originalName.substringBeforeLast('.')
            val ext = safeFile.originalName.substringAfterLast('.', "")
            val suffix = System.currentTimeMillis().toString().takeLast(4)
            destFile = File(restoreDir, if (ext.isNotEmpty()) "${base}_$suffix.$ext" else "${base}_$suffix")
        }
        FileInputStream(vaultFile).use { input ->
            FileOutputStream(destFile).use { output -> input.copyTo(output) }
        }
        if (!destFile.exists()) return false
        MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), arrayOf(mime), null)
        return true
    }

    fun getVaultFile(safeVaultFileName: String): File {
        return File(vaultDir, safeVaultFileName)
    }

    fun getVaultFileUri(safeVaultFileName: String): Uri {
        val file = getVaultFile(safeVaultFileName)
        return Uri.fromFile(file)
    }

    private companion object {
        const val KEY_ALIAS = "vivilo_vault_key"
        val MAGIC = byteArrayOf(0x56, 0x56, 0x4C, 0x31)
        const val KEY_HASH = "safe_pin_hash"
        const val KEY_SALT = "safe_pin_salt"
        const val KEY_ALGO = "safe_pin_algo"
        const val KEY_FAILS = "safe_pin_failed_attempts"
        const val KEY_LOCKED_UNTIL = "safe_pin_locked_until"
        const val MAX_FREE_ATTEMPTS = 5
        const val BASE_LOCKOUT_MS = 30_000L
        const val PBKDF2_ITERATIONS = 120_000
    }
}
