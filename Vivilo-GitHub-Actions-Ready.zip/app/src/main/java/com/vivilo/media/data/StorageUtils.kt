package com.vivilo.media.data

import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.util.Locale
import kotlin.math.log10
import kotlin.math.pow

data class StorageVolumeInfo(
    val name: String,
    val path: String,
    val totalBytes: Long,
    val freeBytes: Long,
    val usedBytes: Long,
    val usageRatio: Float,
    val isPrimary: Boolean,
    val totalFormatted: String,
    val freeFormatted: String,
    val usedFormatted: String
)

data class StorageScanInfo(
    val primaryVolume: StorageVolumeInfo,
    val secondaryVolumes: List<StorageVolumeInfo>,
    val cleanableJunkBytes: Long,
    val cleanableJunkFormatted: String,
    val largeFilesCount: Int,
    val duplicateCandidatesCount: Int
)

object StorageUtils {

    const val LARGE_FILE_THRESHOLD_BYTES = 20L * 1024L * 1024L

    fun getStorageInfo(context: Context, mediaFiles: List<MediaFile> = emptyList()): StorageScanInfo {
        val primaryVolume = getPrimaryStorageInfo()
        val secondaryVolumes = getSecondaryStorageVolumes(context)

        // Only count what clearAppCache() can actually remove. Previously Downloads/*.tmp|log|bak
        // files were counted too, so the banner promised space that the Clean button never freed.
        var junkBytes = 0L
        try {
            context.cacheDir?.let { junkBytes += getFolderSize(it) }
            context.externalCacheDir?.let { junkBytes += getFolderSize(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val largeCount = mediaFiles.count { it.size > LARGE_FILE_THRESHOLD_BYTES }
        val duplicateGroups = findDuplicateGroups(mediaFiles)
        val duplicateCount = duplicateGroups.sumOf { it.size - 1 }

        return StorageScanInfo(
            primaryVolume = primaryVolume,
            secondaryVolumes = secondaryVolumes,
            cleanableJunkBytes = junkBytes,
            cleanableJunkFormatted = formatSize(junkBytes),
            largeFilesCount = largeCount,
            duplicateCandidatesCount = duplicateCount
        )
    }

    /** Cheap snapshot used as the initial UI state; the full scan replaces it a moment later. */
    fun getQuickStorageInfo(): StorageScanInfo = StorageScanInfo(
        primaryVolume = getPrimaryStorageInfo(),
        secondaryVolumes = emptyList(),
        cleanableJunkBytes = 0L,
        cleanableJunkFormatted = formatSize(0L),
        largeFilesCount = 0,
        duplicateCandidatesCount = 0
    )

    fun clearAppCache(context: Context): Long {
        var clearedBytes = 0L
        try {
            context.cacheDir?.let { clearedBytes += deleteFolderContents(it) }
            context.externalCacheDir?.let { clearedBytes += deleteFolderContents(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return clearedBytes
    }

    fun findDuplicateGroups(mediaFiles: List<MediaFile>): List<List<MediaFile>> {
        return mediaFiles
            .filter { !it.isDirectory && it.size > 0L }
            .groupBy { "${it.name.lowercase(Locale.ROOT)}_${it.size}" }
            .values
            .filter { it.size > 1 }
    }

    private fun deleteFolderContents(dir: File): Long {
        if (!dir.exists() || !dir.isDirectory) return 0L
        var deleted = 0L
        dir.listFiles()?.forEach { child ->
            if (child.isDirectory) {
                deleted += deleteFolderContents(child)
                child.delete()
            } else {
                val len = child.length()
                if (child.delete()) {
                    deleted += len
                }
            }
        }
        return deleted
    }

    private fun getPrimaryStorageInfo(): StorageVolumeInfo {
        return try {
            val primaryDir = Environment.getExternalStorageDirectory()
            val stat = StatFs(primaryDir.path)

            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            val freeBlocks = stat.availableBlocksLong

            val totalBytes = (totalBlocks * blockSize).coerceAtLeast(0L)
            val freeBytes = (freeBlocks * blockSize).coerceIn(0L, totalBytes)
            val usedBytes = (totalBytes - freeBytes).coerceAtLeast(0L)
            val ratio = if (totalBytes > 0L) (usedBytes.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f) else 0f

            StorageVolumeInfo(
                name = "Internal storage",
                path = primaryDir.absolutePath,
                totalBytes = totalBytes,
                freeBytes = freeBytes,
                usedBytes = usedBytes,
                usageRatio = ratio,
                isPrimary = true,
                totalFormatted = formatSize(totalBytes),
                freeFormatted = formatSize(freeBytes),
                usedFormatted = formatSize(usedBytes)
            )
        } catch (e: Exception) {
            e.printStackTrace()
            // Never invent numbers: show an honest "unavailable" volume instead of a fake 128 GB.
            StorageVolumeInfo(
                name = "Internal storage",
                path = "",
                totalBytes = 0L,
                freeBytes = 0L,
                usedBytes = 0L,
                usageRatio = 0f,
                isPrimary = true,
                totalFormatted = "Unavailable",
                freeFormatted = "Unavailable",
                usedFormatted = "Unavailable"
            )
        }
    }

    private fun getSecondaryStorageVolumes(context: Context): List<StorageVolumeInfo> {
        val secondaryList = mutableListOf<StorageVolumeInfo>()
        try {
            val externalDirs = context.getExternalFilesDirs(null)
            for (dir in externalDirs) {
                if (dir != null && Environment.isExternalStorageRemovable(dir)) {
                    val stat = StatFs(dir.path)
                    val totalBytes = stat.blockSizeLong * stat.blockCountLong
                    val freeBytes = stat.blockSizeLong * stat.availableBlocksLong
                    val usedBytes = (totalBytes - freeBytes).coerceAtLeast(0L)
                    val ratio = if (totalBytes > 0) (usedBytes.toDouble() / totalBytes.toDouble()).toFloat() else 0f

                    secondaryList.add(
                        StorageVolumeInfo(
                            name = "SD Card",
                            path = dir.absolutePath.substringBefore("/Android/data"),
                            totalBytes = totalBytes,
                            freeBytes = freeBytes,
                            usedBytes = usedBytes,
                            usageRatio = ratio.coerceIn(0f, 1f),
                            isPrimary = false,
                            totalFormatted = formatSize(totalBytes),
                            freeFormatted = formatSize(freeBytes),
                            usedFormatted = formatSize(usedBytes)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return secondaryList
    }

    private fun getFolderSize(dir: File): Long {
        var size = 0L
        if (dir.exists() && dir.isDirectory) {
            dir.listFiles()?.forEach { file ->
                size += if (file.isDirectory) getFolderSize(file) else file.length()
            }
        } else if (dir.exists()) {
            size = dir.length()
        }
        return size
    }

    fun formatSize(sizeBytes: Long): String {
        if (sizeBytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (log10(sizeBytes.toDouble()) / log10(1024.0)).toInt().coerceIn(0, 4)
        return String.format(Locale.US, "%.1f %s", sizeBytes / 1024.0.pow(digitGroups.toDouble()), units[digitGroups])
    }
}
