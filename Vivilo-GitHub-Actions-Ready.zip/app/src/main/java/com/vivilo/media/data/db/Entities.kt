package com.vivilo.media.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_items")
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val uriString: String,
    val name: String,
    val mediaType: String,
    val duration: Long,
    val size: Long,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val uriString: String,
    val name: String,
    val mediaType: String,
    val duration: Long,
    val size: Long,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playback_history")
data class PlaybackHistoryEntity(
    @PrimaryKey val uriString: String,
    val name: String,
    val position: Long,
    val duration: Long,
    val mediaType: String,
    val lastPlayedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey val query: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "safe_files")
data class SafeFileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originalUriString: String,
    val originalName: String,
    val safeVaultFileName: String,
    val mediaType: String,
    val duration: Long,
    val size: Long,
    val addedAt: Long = System.currentTimeMillis()
)
