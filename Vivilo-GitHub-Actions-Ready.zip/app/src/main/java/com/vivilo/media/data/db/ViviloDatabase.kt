package com.vivilo.media.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PlaylistEntity::class,
        PlaylistItemEntity::class,
        FavoriteEntity::class,
        PlaybackHistoryEntity::class,
        SearchHistoryEntity::class,
        SafeFileEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class ViviloDatabase : RoomDatabase() {
    abstract fun dao(): ViviloDao

    companion object {
        @Volatile
        private var INSTANCE: ViviloDatabase? = null

        fun getDatabase(context: Context): ViviloDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ViviloDatabase::class.java,
                    "vivilo_media_db"
                )
                    // Only the legacy v1 schema may be wiped. A blanket destructive fallback would
                    // silently delete playlists, favourites and the Safe folder index (orphaning the
                    // vault files) on any future schema bump; new versions must ship real migrations.
                    .fallbackToDestructiveMigrationFrom(true, 1)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
