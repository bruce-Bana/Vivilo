package com.vivilo.media.data.db

import kotlinx.coroutines.flow.Flow

class ViviloMediaDatabaseRepository(private val dao: ViviloDao) {
    val playlists: Flow<List<PlaylistEntity>> = dao.getAllPlaylists()
    val favorites: Flow<List<FavoriteEntity>> = dao.getAllFavorites()
    val history: Flow<List<PlaybackHistoryEntity>> = dao.getAllHistory()
    val recentSearches: Flow<List<SearchHistoryEntity>> = dao.getRecentSearches()
    val safeFiles: Flow<List<SafeFileEntity>> = dao.getAllSafeFiles()

    suspend fun addSafeFile(file: SafeFileEntity): Long {
        return dao.insertSafeFile(file)
    }

    suspend fun removeSafeFile(id: Long) {
        dao.deleteSafeFile(id)
    }

    suspend fun getSafeFileById(id: Long): SafeFileEntity? {
        return dao.getSafeFileById(id)
    }

    suspend fun createPlaylist(name: String): Long {
        return dao.insertPlaylist(PlaylistEntity(title = name))
    }

    suspend fun deletePlaylist(playlistId: Long) {
        dao.clearPlaylistItems(playlistId)
        dao.deletePlaylist(playlistId)
    }

    fun getPlaylistItems(playlistId: Long): Flow<List<PlaylistItemEntity>> {
        return dao.getPlaylistItems(playlistId)
    }

    suspend fun addToPlaylist(playlistId: Long, uriString: String, name: String, mediaType: String, duration: Long, size: Long) {
        dao.insertPlaylistItem(
            PlaylistItemEntity(
                playlistId = playlistId,
                uriString = uriString,
                name = name,
                mediaType = mediaType,
                duration = duration,
                size = size
            )
        )
    }

    suspend fun removeFromPlaylist(itemId: Long) {
        dao.deletePlaylistItem(itemId)
    }

    suspend fun toggleFavorite(uriString: String, name: String, mediaType: String, duration: Long, size: Long, isFav: Boolean) {
        if (isFav) {
            dao.deleteFavorite(uriString)
        } else {
            dao.insertFavorite(
                FavoriteEntity(
                    uriString = uriString,
                    name = name,
                    mediaType = mediaType,
                    duration = duration,
                    size = size
                )
            )
        }
    }

    fun isFavorite(uriString: String): Flow<Boolean> {
        return dao.isFavorite(uriString)
    }

    suspend fun updatePlaybackHistory(uriString: String, name: String, position: Long, duration: Long, mediaType: String) {
        dao.insertOrUpdateHistory(
            PlaybackHistoryEntity(
                uriString = uriString,
                name = name,
                position = position,
                duration = duration,
                mediaType = mediaType,
                lastPlayedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun getResumePosition(uriString: String): Long {
        return dao.getHistoryForUri(uriString)?.position ?: 0L
    }

    suspend fun clearHistory() {
        dao.clearHistory()
    }

    suspend fun saveSearchQuery(query: String) {
        if (query.isNotBlank()) {
            dao.insertSearch(SearchHistoryEntity(query = query.trim()))
        }
    }

    suspend fun deleteSearchQuery(query: String) {
        dao.deleteSearch(query)
    }
}
