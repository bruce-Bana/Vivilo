package com.vivilo.media.service

import android.content.ComponentName
import android.content.Context
import android.os.SystemClock
import android.media.audiofx.Equalizer
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import android.net.Uri
import kotlinx.coroutines.Job
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionToken
import com.vivilo.media.data.MediaFile
import com.vivilo.media.data.db.ViviloDatabase
import com.vivilo.media.data.db.ViviloMediaDatabaseRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class PlaybackManager private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val dbRepo = ViviloMediaDatabaseRepository(ViviloDatabase.getDatabase(appContext).dao())

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(appContext)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            true
        )
        .setHandleAudioBecomingNoisy(true)
        .build()

    val mediaSession: MediaSession = MediaSession.Builder(appContext, exoPlayer).build()

    private var audioEqualizer: Equalizer? = null

    // A MediaController connection is what starts ViviloMediaPlaybackService, which in turn
    // promotes playback to a foreground service with a media notification. Without it audio
    // stops as soon as the app is backgrounded. The future is held so it is not collected.
    private var controllerFuture: Any? = null
    private var lastHistorySaveAt = 0L

    /** Set by the video screen so the activity knows when leaving the app should enter Picture-in-Picture. */
    @Volatile
    var videoScreenVisible: Boolean = false

    private var sleepJob: Job? = null
    private val _sleepTimerEndsAt = MutableStateFlow<Long?>(null)
    val sleepTimerEndsAt: StateFlow<Long?> = _sleepTimerEndsAt.asStateFlow()

    private val _currentFile = MutableStateFlow<MediaFile?>(null)
    val currentFile: StateFlow<MediaFile?> = _currentFile.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _playerError = MutableStateFlow<String?>(null)
    val playerError: StateFlow<String?> = _playerError.asStateFlow()

    private val _aspectRatioMode = MutableStateFlow(0) // 0: Fit, 1: Fill, 2: 16:9
    val aspectRatioMode: StateFlow<Int> = _aspectRatioMode.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private var originalQueue: List<MediaFile> = emptyList()

    private val _queue = MutableStateFlow<List<MediaFile>>(emptyList())
    val queue: StateFlow<List<MediaFile>> = _queue.asStateFlow()

    private val _queueIndex = MutableStateFlow(0)
    val queueIndex: StateFlow<Int> = _queueIndex.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _speed = MutableStateFlow(1.0f)
    val speed: StateFlow<Float> = _speed.asStateFlow()

    private val _volume = MutableStateFlow(1.0f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    private val _equalizerPreset = MutableStateFlow("Normal")
    val equalizerPreset: StateFlow<String> = _equalizerPreset.asStateFlow()

    private val _equalizerBandLevels = MutableStateFlow(listOf(0.5f, 0.5f, 0.5f, 0.5f, 0.5f))
    val equalizerBandLevels: StateFlow<List<Float>> = _equalizerBandLevels.asStateFlow()

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _isPlaying.value = playing
                if (playing) {
                    _playerError.value = null
                } else {
                    // Persist the exact resume point when playback pauses or stops.
                    saveHistoryNow()
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                _isBuffering.value = (state == Player.STATE_BUFFERING)
                if (state == Player.STATE_READY) {
                    _playerError.value = null
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                } else if (state == Player.STATE_ENDED) {
                    if (_repeatMode.value != Player.REPEAT_MODE_ONE) {
                        playNext(fromAutoAdvance = true)
                    }
                }
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                initAndApplyEqualizer(audioSessionId, _equalizerPreset.value)
            }

            override fun onPlayerError(error: PlaybackException) {
                _isPlaying.value = false
                _isBuffering.value = false
                val msg = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "Media file not found on device"
                    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> "Hardware video/audio decoder unavailable for this format"
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED -> "Unsupported media codec or container format"
                    PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> "Storage read permission required"
                    else -> error.localizedMessage ?: "Playback error: ${error.errorCodeName}"
                }
                _playerError.value = msg
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                _playerError.value = null
                _duration.value = exoPlayer.duration.coerceAtLeast(0L)
            }
        })

        // Ticker for position updates. History is persisted at most every few seconds instead of
        // on every tick (previously ~3 database writes per second for the whole playback).
        scope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _currentPosition.value = exoPlayer.currentPosition
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)

                    val now = SystemClock.elapsedRealtime()
                    if (now - lastHistorySaveAt >= HISTORY_SAVE_INTERVAL_MS) {
                        lastHistorySaveAt = now
                        saveHistoryNow()
                    }
                }
                delay(300L)
            }
        }
    }

    private fun saveHistoryNow() {
        val file = _currentFile.value ?: return
        val pos = exoPlayer.currentPosition
        val dur = exoPlayer.duration.coerceAtLeast(0L)
        if (pos <= 1000L) return
        // Reaching the end clears the resume point so the next play starts from the beginning.
        val savedPos = if (dur > 0L && pos >= dur - 3000L) 0L else pos
        scope.launch {
            try {
                dbRepo.updatePlaybackHistory(
                    uriString = file.uri.toString(),
                    name = file.name,
                    position = savedPos,
                    duration = dur,
                    mediaType = if (file.isVideo) "video" else "audio"
                )
            } catch (_: Exception) {
                // History is best-effort; never let a DB error interrupt playback.
            }
        }
    }

    private fun ensureServiceConnected() {
        if (controllerFuture != null) return
        try {
            val token = SessionToken(
                appContext,
                ComponentName(appContext, com.vivilo.media.service.ViviloMediaPlaybackService::class.java)
            )
            controllerFuture = MediaController.Builder(appContext, token).buildAsync()
        } catch (_: Exception) {
            // Playback still works in the foreground without the service.
        }
    }

    private fun presetNormalizedBands(preset: String): List<Float> = when (preset) {
        "Bass Boost" -> listOf(0.92f, 0.78f, 0.50f, 0.45f, 0.48f)
        "Vocal" -> listOf(0.35f, 0.55f, 0.85f, 0.80f, 0.55f)
        "Rock" -> listOf(0.82f, 0.60f, 0.42f, 0.72f, 0.85f)
        "Pop" -> listOf(0.42f, 0.72f, 0.82f, 0.70f, 0.45f)
        "Jazz" -> listOf(0.68f, 0.52f, 0.62f, 0.75f, 0.68f)
        "Electronic" -> listOf(0.90f, 0.72f, 0.45f, 0.76f, 0.88f)
        "Classical" -> listOf(0.65f, 0.55f, 0.48f, 0.65f, 0.78f)
        else -> listOf(0.50f, 0.50f, 0.50f, 0.50f, 0.50f)
    }

    private fun initAndApplyEqualizer(audioSessionId: Int, preset: String) {
        if (audioSessionId == C.AUDIO_SESSION_ID_UNSET || audioSessionId == 0) return
        try {
            audioEqualizer?.release()
            val eq = Equalizer(0, audioSessionId).apply {
                enabled = preset != "Normal"
            }
            val bands = eq.numberOfBands.toInt()
            val range = eq.bandLevelRange
            val minLevel = range[0]
            val maxLevel = range[1]
            val targetNormalized = presetNormalizedBands(preset)
            for (i in 0 until bands) {
                val norm = targetNormalized.getOrElse(i) { 0.5f }
                val level = (minLevel + (maxLevel - minLevel) * norm).toInt().toShort()
                eq.setBandLevel(i.toShort(), level)
            }
            audioEqualizer = eq
        } catch (_: Exception) {
            // Device audio HAL may not support Equalizer in some environments
        }
    }

    fun playFile(file: MediaFile, newQueue: List<MediaFile> = emptyList()) {
        if (!file.isVideo && !file.isAudio) return

        _currentFile.value = file
        // Keep the queue to the same kind of media as the file being played, so tapping a song
        // does not roll on into a video (and vice versa).
        val playableQueue = newQueue.filter { if (file.isVideo) it.isVideo else it.isAudio }
        if (playableQueue.isNotEmpty()) {
            originalQueue = playableQueue
            val activeQueue = if (_isShuffle.value) {
                val rest = playableQueue.filter { it.uri != file.uri }.shuffled()
                listOf(file) + rest
            } else {
                playableQueue
            }
            _queue.value = activeQueue
            _queueIndex.value = activeQueue.indexOfFirst { it.uri == file.uri }.coerceAtLeast(0)
        } else {
            val existingIdx = _queue.value.indexOfFirst { it.uri == file.uri }
            if (existingIdx >= 0) {
                _queueIndex.value = existingIdx
            } else {
                originalQueue = listOf(file)
                _queue.value = listOf(file)
                _queueIndex.value = 0
            }
        }

        ensureServiceConnected()

        scope.launch {
            _playerError.value = null
            _currentPosition.value = 0L
            try {
                val resumePos = dbRepo.getResumePosition(file.uri.toString())

                val metadata = MediaMetadata.Builder()
                    .setTitle(file.name.substringBeforeLast('.'))
                    .setDisplayTitle(file.name.substringBeforeLast('.'))
                    .build()

                val item = MediaItem.Builder()
                    .setUri(file.uri)
                    .setMediaMetadata(metadata)
                    .build()

                exoPlayer.setMediaItem(item)
                exoPlayer.prepare()
                if (resumePos > 1000 && (file.duration <= 0L || resumePos < file.duration - 5000L)) {
                    exoPlayer.seekTo(resumePos)
                    _currentPosition.value = resumePos
                }
                exoPlayer.playWhenReady = true
            } catch (e: Exception) {
                _playerError.value = "Failed to load media: ${e.localizedMessage ?: "Unknown error"}"
            }
        }
    }

    /** True when [file] is already loaded and active, so re-opening it must not restart playback. */
    fun isActivelyLoaded(file: MediaFile): Boolean {
        val state = exoPlayer.playbackState
        return _currentFile.value?.uri == file.uri &&
            state != Player.STATE_IDLE &&
            state != Player.STATE_ENDED
    }

    /** Pauses playback after [minutes]; 0 cancels the timer. */
    fun setSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) {
            _sleepTimerEndsAt.value = null
            return
        }
        val ms = minutes * 60_000L
        _sleepTimerEndsAt.value = System.currentTimeMillis() + ms
        sleepJob = scope.launch {
            delay(ms)
            exoPlayer.pause()
            _sleepTimerEndsAt.value = null
        }
    }

    /** Attaches an external subtitle file (.srt/.vtt/.ass/.ttml) to the current video, keeping the position. */
    fun addSubtitle(subtitleUri: Uri, fileName: String) {
        val file = _currentFile.value ?: return
        val mime = when (fileName.substringAfterLast('.', "").lowercase()) {
            "vtt" -> MimeTypes.TEXT_VTT
            "ass", "ssa" -> MimeTypes.TEXT_SSA
            "ttml", "xml", "dfxp" -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val subtitle = MediaItem.SubtitleConfiguration.Builder(subtitleUri)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val title = file.name.substringBeforeLast('.')
        val item = MediaItem.Builder()
            .setUri(file.uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setDisplayTitle(title).build())
            .setSubtitleConfigurations(listOf(subtitle))
            .build()
        val position = exoPlayer.currentPosition
        val resume = exoPlayer.playWhenReady
        exoPlayer.setMediaItem(item, position)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = resume
    }

    fun stopAndClear() {
        exoPlayer.stop()
        exoPlayer.clearMediaItems()
        _currentFile.value = null
        _isPlaying.value = false
        _currentPosition.value = 0L
        _duration.value = 0L
        _playerError.value = null
    }

    fun retry() {
        _currentFile.value?.let { file ->
            playFile(file, _queue.value)
        }
    }

    fun clearError() {
        _playerError.value = null
    }

    fun cycleAspectRatioMode(): Int {
        val next = (_aspectRatioMode.value + 1) % 3
        _aspectRatioMode.value = next
        return next
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            if (exoPlayer.playbackState == Player.STATE_ENDED) {
                exoPlayer.seekTo(0L)
            }
            exoPlayer.play()
        }
    }

    fun seekTo(positionMs: Long) {
        val clamped = positionMs.coerceIn(0L, _duration.value.coerceAtLeast(0L))
        _currentPosition.value = clamped
        exoPlayer.seekTo(clamped)
    }

    fun playNext(fromAutoAdvance: Boolean = false) {
        val q = _queue.value
        if (q.isEmpty()) return
        if (q.size == 1 && fromAutoAdvance && _repeatMode.value == Player.REPEAT_MODE_OFF) {
            _isPlaying.value = false
            return
        }
        var nextIdx = _queueIndex.value + 1
        if (nextIdx >= q.size) {
            if (_repeatMode.value == Player.REPEAT_MODE_ALL || !fromAutoAdvance) {
                nextIdx = 0
            } else {
                _isPlaying.value = false
                return
            }
        }
        _queueIndex.value = nextIdx
        playFile(q[nextIdx])
    }

    fun playPrevious() {
        val q = _queue.value
        if (q.isEmpty()) return
        if (exoPlayer.currentPosition > 3000L) {
            seekTo(0L)
            return
        }
        var prevIdx = _queueIndex.value - 1
        if (prevIdx < 0) {
            prevIdx = if (_repeatMode.value == Player.REPEAT_MODE_ALL) q.size - 1 else q.lastIndex
        }
        _queueIndex.value = prevIdx
        playFile(q[prevIdx])
    }

    fun toggleShuffle() {
        val newShuffle = !_isShuffle.value
        _isShuffle.value = newShuffle
        val current = _currentFile.value
        if (newShuffle && _queue.value.isNotEmpty()) {
            val rest = _queue.value.filter { it.uri != current?.uri }.shuffled()
            _queue.value = if (current != null) listOf(current) + rest else rest
            _queueIndex.value = 0
        } else if (!newShuffle && originalQueue.isNotEmpty()) {
            _queue.value = originalQueue
            _queueIndex.value = if (current != null) {
                originalQueue.indexOfFirst { it.uri == current.uri }.coerceAtLeast(0)
            } else 0
        }
    }

    fun cycleRepeatMode() {
        val nextMode = when (_repeatMode.value) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        _repeatMode.value = nextMode
        // ExoPlayer only ever holds one item here (the queue is managed by this class), so
        // delegating REPEAT_MODE_ALL to it would loop the current track forever instead of
        // advancing. Only "repeat one" is handed to ExoPlayer; "repeat all" is handled in playNext().
        exoPlayer.repeatMode = if (nextMode == Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    fun setSpeed(speedVal: Float) {
        _speed.value = speedVal
        exoPlayer.setPlaybackSpeed(speedVal)
    }

    fun setVolume(volVal: Float) {
        _volume.value = volVal
        exoPlayer.volume = volVal
    }

    fun setEqualizerPreset(preset: String) {
        _equalizerPreset.value = preset
        _equalizerBandLevels.value = presetNormalizedBands(preset)
        initAndApplyEqualizer(exoPlayer.audioSessionId, preset)
    }

    fun release() {
        try {
            audioEqualizer?.release()
            audioEqualizer = null
        } catch (_: Exception) {}
        mediaSession.release()
        exoPlayer.release()
    }

    companion object {
        private const val HISTORY_SAVE_INTERVAL_MS = 5_000L

        @Volatile
        private var INSTANCE: PlaybackManager? = null

        fun getInstance(context: Context): PlaybackManager {
            return INSTANCE ?: synchronized(this) {
                val instance = PlaybackManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
