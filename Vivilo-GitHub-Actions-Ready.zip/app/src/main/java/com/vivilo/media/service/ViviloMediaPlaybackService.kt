package com.vivilo.media.service

import android.content.Intent
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class ViviloMediaPlaybackService : MediaSessionService() {

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return PlaybackManager.getInstance(this).mediaSession
    }

    /**
     * Swiping the app away from recents should not leave an idle foreground service behind.
     * If something is actively playing we keep going (that is the point of background playback).
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = PlaybackManager.getInstance(this).exoPlayer
        if (!player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }
}
