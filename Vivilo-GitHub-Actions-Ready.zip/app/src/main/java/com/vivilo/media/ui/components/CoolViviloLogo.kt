package com.vivilo.media.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vivilo.media.ui.theme.PrimaryBlue

@Composable
fun CoolViviloLogo(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp
) {
    val googleBlue = Color(0xFF1B6EF3)
    val googleRed = Color(0xFFEA4335)
    val googleYellow = Color(0xFFFBBC05)
    val googleGreen = Color(0xFF34A853)

    Box(
        modifier = modifier
            .size(size)
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(size * 0.28f),
                ambientColor = googleBlue.copy(alpha = 0.4f),
                spotColor = googleBlue.copy(alpha = 0.4f)
            )
            .clip(RoundedCornerShape(size * 0.28f))
            .background(
                Brush.sweepGradient(
                    listOf(
                        googleBlue,
                        googleRed,
                        googleYellow,
                        googleGreen,
                        googleBlue
                    )
                )
            )
            .padding(2.5.dp)
            .clip(RoundedCornerShape(size * 0.23f))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        googleBlue,
                        Color(0xFF0B57D0)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val foldSize = size.toPx() * 0.32f
            val path = Path().apply {
                moveTo(size.toPx() - foldSize, 0f)
                lineTo(size.toPx(), 0f)
                lineTo(size.toPx(), foldSize)
                close()
            }
            drawPath(
                path = path,
                color = googleYellow.copy(alpha = 0.9f)
            )

            drawCircle(
                color = googleGreen.copy(alpha = 0.85f),
                radius = size.toPx() * 0.12f,
                center = Offset(size.toPx() * 0.18f, size.toPx() * 0.82f)
            )
        }

        Text(
            text = "V",
            style = MaterialTheme.typography.titleMedium.copy(
                fontSize = (size.value * 0.52f).sp,
                fontWeight = FontWeight.ExtraBold
            ),
            color = Color.White
        )
    }
}

@Composable
fun CoolViviloHeaderBadge() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        CoolViviloLogo(size = 40.dp)
        Column(verticalArrangement = Arrangement.Center) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Vivilo",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(PrimaryBlue.copy(alpha = 0.15f))
                        .border(1.dp, PrimaryBlue.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "MEDIA",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = PrimaryBlue
                    )
                }
            }
            Text(
                text = "Media player & file manager",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
