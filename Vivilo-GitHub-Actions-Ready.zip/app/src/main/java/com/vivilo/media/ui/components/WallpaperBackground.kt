package com.vivilo.media.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.vivilo.media.ui.theme.LocalAppPreferences
import com.vivilo.media.ui.theme.WallpaperOption

@Composable
fun WallpaperBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val prefs = LocalAppPreferences.current
    val wallpaper = prefs.wallpaper

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (wallpaper != WallpaperOption.NONE) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val brush = Brush.verticalGradient(
                    colors = listOf(
                        wallpaper.topColor,
                        wallpaper.bottomColor
                    )
                )
                drawRect(brush = brush)

                // Optional grid matrix pattern for Tech Grid or Starfield
                if (wallpaper.isGrid) {
                    val stepPx = 36.dp.toPx()
                    val gridColor = Color.White.copy(alpha = 0.05f)
                    var x = 0f
                    while (x < size.width) {
                        drawLine(
                            color = gridColor,
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 1f
                        )
                        x += stepPx
                    }
                    var y = 0f
                    while (y < size.height) {
                        drawLine(
                            color = gridColor,
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1f
                        )
                        y += stepPx
                    }
                } else {
                    // Subtle atmospheric ambient glow circles
                    drawCircle(
                        color = Color.White.copy(alpha = 0.04f),
                        radius = size.width * 0.7f,
                        center = Offset(size.width * 0.8f, size.height * 0.2f)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.03f),
                        radius = size.width * 0.9f,
                        center = Offset(size.width * 0.2f, size.height * 0.85f)
                    )
                }
            }
        }

        content()
    }
}
