package com.vivilo.media.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import com.vivilo.media.data.MediaFile
import com.vivilo.media.data.MimeTypeDetector
import com.vivilo.media.data.SafeMoveResult
import com.vivilo.media.data.db.PlaylistEntity
import com.vivilo.media.ui.components.ThemeSettingsSheet
import com.vivilo.media.ui.components.WallpaperBackground
import com.vivilo.media.viewmodel.MainViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(
    viewModel: MainViewModel,
    onNavigateToPlayer: (MediaFile) -> Unit
) {
    val context = LocalContext.current
    val mediaFiles by viewModel.mediaFiles.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    // 0 = Home, 1 = All, 2 = Videos, 3 = Audio, 4 = Images, 5 = Documents, 6 = Storage
    var selectedCategoryIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var isGridView by remember { mutableStateOf(true) }
    var showThemeSettings by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var sortMode by remember { mutableIntStateOf(0) } // 0 newest, 1 name, 2 largest
    val sortLabels = listOf("Newest first", "Name", "Largest first")
    var currentBottomTab by remember { mutableIntStateOf(0) } // 0: Browse, 1: Clean, 2: Playlists & Favorites

    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    val tabNames = listOf("Home", "All Files", "Videos", "Audio", "Images", "Documents", "Storage")

    val storageFiles by viewModel.storageFiles.collectAsState()
    val currentPath by viewModel.currentPath.collectAsState()

    val playlists by viewModel.playlists.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val history by viewModel.history.collectAsState()
    val recentSearches by viewModel.recentSearches.collectAsState()

    val storageScanInfo by viewModel.storageScanInfo.collectAsState()
    val safeFiles by viewModel.safeFiles.collectAsState()
    val isSafeFolderUnlocked by viewModel.isSafeFolderUnlocked.collectAsState()
    val isSafeFolderPinSet by viewModel.isSafeFolderPinSet.collectAsState()

    var showSafeFolderPinDialog by remember { mutableStateOf(false) }
    var showSafeFolderModal by remember { mutableStateOf(false) }
    var pendingSafeFolderFiles by remember { mutableStateOf<List<MediaFile>?>(null) }

    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val isSelectionMode by viewModel.isSelectionMode.collectAsState()

    var showCreatePlaylistModal by remember { mutableStateOf(false) }
    var addSelectedAfterCreate by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var showAddToPlaylistDialog by remember { mutableStateOf(false) }
    var selectedPlaylistForDetail by remember { mutableStateOf<PlaylistEntity?>(null) }

    val playbackManager = viewModel.playbackManager
    val activePlayingFile by playbackManager.currentFile.collectAsState()
    val isPlaying by playbackManager.isPlaying.collectAsState()
    val activePosition by playbackManager.currentPosition.collectAsState()
    val activeDuration by playbackManager.duration.collectAsState()

    val filteredFiles = remember(mediaFiles, storageFiles, selectedCategoryIndex, searchQuery, sortMode) {
        val baseList = when (selectedCategoryIndex) {
            1 -> mediaFiles
            2 -> mediaFiles.filter { it.isVideo }
            3 -> mediaFiles.filter { it.isAudio }
            4 -> mediaFiles.filter { it.isImage }
            5 -> mediaFiles.filter { it.isDocument }
            6 -> storageFiles
            else -> mediaFiles
        }
        val searched = if (searchQuery.isBlank()) {
            baseList
        } else {
            baseList.filter { it.name.contains(searchQuery, ignoreCase = true) }
        }
        // Folders always stay on top in the Storage browser; sorting applies within each group.
        val comparator: Comparator<MediaFile> = when (sortMode) {
            1 -> compareBy<MediaFile> { !it.isDirectory }.thenBy { it.name.lowercase() }
            2 -> compareBy<MediaFile> { !it.isDirectory }.thenByDescending { it.size }
            else -> compareBy<MediaFile> { !it.isDirectory }.thenByDescending { it.dateAdded }
        }
        searched.sortedWith(comparator)
    }

    // Android 11+: originals the app doesn't own are deleted through one system confirmation dialog.
    val deleteLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()
    ) { viewModel.loadMediaFiles() }
    val onSafeMoveResult: (SafeMoveResult) -> Unit = { result ->
        showSafeMoveToast(context, result)
        if (result.pendingDeleteUris.isNotEmpty() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val request = android.provider.MediaStore.createDeleteRequest(context.contentResolver, result.pendingDeleteUris)
                deleteLauncher.launch(androidx.activity.result.IntentSenderRequest.Builder(request.intentSender).build())
            } catch (_: Exception) {
                // Leave the originals; the toast already explained what to do.
            }
        }
    }

    val permissions = remember {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> listOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
                Manifest.permission.POST_NOTIFICATIONS
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> listOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.POST_NOTIFICATIONS
            )
            else -> listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    var permissionResultReceived by remember { mutableStateOf(false) }
    val permissionState = rememberMultiplePermissionsState(permissions) {
        permissionResultReceived = true
    }
    // Notification permission only affects the playback notification; it must never count as
    // "media access", otherwise allowing notifications alone would hide the permission prompt.
    val hasMediaAccess = permissionState.permissions.any {
        it.permission != Manifest.permission.POST_NOTIFICATIONS && it.status.isGranted
    }
    var requestedPermissionsOnce by remember { mutableStateOf(false) }
    // After the system has stopped showing the dialog, the only way forward is app settings.
    val permissionPermanentlyDenied =
        permissionResultReceived && !hasMediaAccess && !permissionState.shouldShowRationale

    val root = remember { Environment.getExternalStorageDirectory().absolutePath }
    val isStorageTab = selectedCategoryIndex == 6
    val showBackButton = isStorageTab && currentPath != root && currentPath != null

    BackHandler(
        enabled = selectedPlaylistForDetail != null ||
            showAddToPlaylistDialog ||
            isSelectionMode ||
            isSearchActive ||
            searchQuery.isNotEmpty() ||
            showBackButton ||
            selectedCategoryIndex != 0 ||
            currentBottomTab != 0
    ) {
        when {
            selectedPlaylistForDetail != null -> selectedPlaylistForDetail = null
            showAddToPlaylistDialog -> showAddToPlaylistDialog = false
            isSelectionMode -> viewModel.clearSelection()
            isSearchActive || searchQuery.isNotEmpty() -> {
                isSearchActive = false
                searchQuery = ""
                focusManager.clearFocus()
            }
            showBackButton -> viewModel.navigateUp()
            selectedCategoryIndex != 0 -> selectedCategoryIndex = 0
            currentBottomTab != 0 -> currentBottomTab = 0
        }
    }

    LaunchedEffect(hasMediaAccess) {
        if (hasMediaAccess) {
            viewModel.loadMediaFiles()
            viewModel.loadStorageFiles()
        } else if (!requestedPermissionsOnce) {
            requestedPermissionsOnce = true
            permissionState.launchMultiplePermissionRequest()
        }
    }

    // Opening search swaps the header for the search bar; without this the keyboard never appeared
    // and the user had to tap the field a second time.
    LaunchedEffect(isSearchActive) {
        if (isSearchActive) {
            delay(80L)
            runCatching { focusRequester.requestFocus() }
        }
    }

    if (showThemeSettings) {
        ThemeSettingsSheet(
            onDismissRequest = { showThemeSettings = false }
        )
    }

    WallpaperBackground {
        Scaffold(
            containerColor = Color.Transparent,
            floatingActionButton = {
                if (!isSelectionMode) {
                    FloatingActions(
                        currentTab = currentBottomTab,
                        showViewToggle = currentBottomTab == 0 && hasMediaAccess &&
                            (selectedCategoryIndex != 0 || searchQuery.isNotEmpty()) && filteredFiles.isNotEmpty(),
                        isGridView = isGridView,
                        onToggleView = { isGridView = !isGridView },
                        sortLabel = sortLabels[sortMode],
                        onCycleSort = {
                            sortMode = (sortMode + 1) % sortLabels.size
                            Toast.makeText(context, "Sorted by ${sortLabels[sortMode]}", Toast.LENGTH_SHORT).show()
                        },
                        onSafeFolder = {
                            if (isSafeFolderUnlocked) {
                                showSafeFolderModal = true
                            } else {
                                pendingSafeFolderFiles = null
                                showSafeFolderPinDialog = true
                            }
                        },
                        onNewPlaylist = {
                            addSelectedAfterCreate = false
                            showCreatePlaylistModal = true
                        }
                    )
                }
            },
            topBar = {
                if (isSelectionMode) {
                    TopAppBar(
                        title = { Text("${selectedFiles.size} selected", fontWeight = FontWeight.Bold) },
                        navigationIcon = {
                            IconButton(
                                onClick = { viewModel.clearSelection() },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("selection_clear_button")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel selection")
                            }
                        },
                        actions = {
                            androidx.compose.material3.TextButton(
                                onClick = { viewModel.selectAll(filteredFiles) },
                                modifier = Modifier.testTag("selection_select_all_button")
                            ) { Text("Select all") }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                    )

                } else if (currentBottomTab == 0) {
                    Column(modifier = Modifier.statusBarsPadding()) {
                        if (selectedCategoryIndex == 0 && searchQuery.isEmpty() && !isSearchActive) {
                            GoogleFilesHomeHeader(
                                searchQuery = searchQuery,
                                onSearchQueryChange = {
                                    searchQuery = it
                                    if (it.isNotEmpty()) isSearchActive = true
                                },
                                onSearchOpen = { isSearchActive = true },
                                onRefreshLibrary = {
                                    viewModel.loadMediaFiles()
                                    viewModel.loadStorageFiles(currentPath)
                                    Toast.makeText(context, "Refreshing media library...", Toast.LENGTH_SHORT).show()
                                },
                                onOpenSettings = { showThemeSettings = true }
                            )
                        } else {
                            HumanTopBar(
                                searchQuery = searchQuery,
                                onSearchQueryChange = { searchQuery = it },
                                onSearchClose = {
                                    isSearchActive = false
                                    searchQuery = ""
                                    focusManager.clearFocus()
                                },
                                onSearchSubmit = { query ->
                                    if (query.isNotBlank()) {
                                        viewModel.saveSearchQuery(query)
                                    }
                                    focusManager.clearFocus()
                                },
                                showBackButton = selectedCategoryIndex != 0 || showBackButton || isSearchActive,
                                onBackClick = {
                                    if (showBackButton) {
                                        viewModel.navigateUp()
                                    } else {
                                        selectedCategoryIndex = 0
                                        searchQuery = ""
                                        isSearchActive = false
                                        focusManager.clearFocus()
                                    }
                                },
                                isGridView = isGridView,
                                onToggleViewMode = { isGridView = !isGridView },
                                focusRequester = focusRequester,
                                recentSearches = recentSearches,
                                onRecentSearchClick = { q -> searchQuery = q },
                                onDeleteRecentSearch = { q -> viewModel.deleteSearchQuery(q) },
                                matchCount = if (searchQuery.isNotBlank()) filteredFiles.size else null
                            )
                        }

                        MediaFilterTopTabRow(
                            selectedIndex = selectedCategoryIndex,
                            onSelectTab = { index ->
                                selectedCategoryIndex = index
                                if (index == 6) {
                                    viewModel.loadStorageFiles(currentPath)
                                }
                            },
                            mediaFiles = mediaFiles,
                            storageFilesCount = storageFiles.size
                        )
                    }
                } else if (currentBottomTab == 1) {
                    TopAppBar(
                        title = { Text("Space Cleaner", fontWeight = FontWeight.Bold) },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                    )
                } else {
                    TopAppBar(
                        title = { Text("Playlists & Favorites", fontWeight = FontWeight.Bold) },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                    )
                }
            },
            bottomBar = {
                Column {
                    // DOCKED FLOATING MINI-PLAYER
                    activePlayingFile?.let { playingFile ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    viewModel.openMediaFile(playingFile)
                                    onNavigateToPlayer(playingFile)
                                }
                                .testTag("mini_player_bar"),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            tonalElevation = 8.dp
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (playingFile.isVideo) Icons.Default.VideoFile else Icons.Default.AudioFile,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = playingFile.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${formatDuration(activePosition)} / ${formatDuration(activeDuration)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f)
                                        )
                                    }

                                    IconButton(
                                        onClick = { playbackManager.togglePlayPause() },
                                        modifier = Modifier
                                            .size(48.dp)
                                            .testTag("mini_player_play_pause")
                                    ) {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = if (isPlaying) "Pause" else "Play",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(30.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = { playbackManager.playNext() },
                                        modifier = Modifier
                                            .size(48.dp)
                                            .testTag("mini_player_next")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SkipNext,
                                            contentDescription = "Next",
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }

                                    IconButton(
                                        onClick = { playbackManager.stopAndClear() },
                                        modifier = Modifier
                                            .size(48.dp)
                                            .testTag("mini_player_close")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Close Mini Player",
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }

                                if (activeDuration > 0) {
                                    LinearProgressIndicator(
                                        progress = { (activePosition.toFloat() / activeDuration.toFloat()).coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(3.dp),
                                        color = MaterialTheme.colorScheme.primary,
                                        trackColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f)
                                    )
                                }
                            }
                        }
                    }

                    // FLOATING NAVIGATION PILL (or the floating selection bar while selecting)
                    if (isSelectionMode) {
                        FloatingSelectionBar(
                            onSafeFolder = {
                                val filesToMove = selectedFiles.toList()
                                if (!isSafeFolderPinSet) {
                                    pendingSafeFolderFiles = filesToMove
                                    showSafeFolderPinDialog = true
                                } else {
                                    viewModel.moveToSafeFolder(filesToMove) { result -> onSafeMoveResult(result) }
                                }
                            },
                            onShare = {
                                shareSelectedFiles(context, selectedFiles.toList())
                                viewModel.clearSelection()
                            },
                            onDelete = { showDeleteConfirm = true },
                            onAddToPlaylist = {
                                if (playlists.isEmpty()) {
                                    addSelectedAfterCreate = true
                                    showCreatePlaylistModal = true
                                } else {
                                    showAddToPlaylistDialog = true
                                }
                            }
                        )
                    } else {
                        FloatingNavPill(
                            selectedTab = currentBottomTab,
                            onSelect = { tab ->
                                if (tab == 0) {
                                    selectedCategoryIndex = 0
                                    isSearchActive = false
                                    searchQuery = ""
                                }
                                currentBottomTab = tab
                            }
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(Color.Transparent)
            ) {
                when {
                    currentBottomTab == 1 -> {
                        CleanScreen(
                            mediaFiles = mediaFiles,
                            storageScanInfo = storageScanInfo,
                            onCleanJunk = { callback -> viewModel.clearJunkCache(callback) },
                            onNavigateToVideos = {
                                currentBottomTab = 0
                                selectedCategoryIndex = 2 // Videos tab
                            }
                        )
                    }
                    currentBottomTab == 2 -> {
                        PlaylistsAndFavoritesScreen(
                            playlists = playlists,
                            favorites = favorites,
                            history = history,
                            onCreatePlaylistClick = {
                                addSelectedAfterCreate = false
                                showCreatePlaylistModal = true
                            },
                            onPlaylistClick = { playlist ->
                                selectedPlaylistForDetail = playlist
                            },
                            onDeletePlaylistClick = { playlist ->
                                viewModel.deletePlaylist(playlist.id)
                                Toast.makeText(context, "Deleted \"${playlist.title}\"", Toast.LENGTH_SHORT).show()
                            },
                            onFavoriteClick = { fav ->
                                val detected = MimeTypeDetector.detect(fav.name)
                                val file = MediaFile(
                                    id = fav.uriString.hashCode().toLong(),
                                    uri = fav.uriString.toUri(),
                                    name = fav.name,
                                    duration = fav.duration,
                                    size = fav.size,
                                    mimeType = detected.mimeType,
                                    dateAdded = fav.addedAt / 1000,
                                    isVideo = fav.mediaType == "video" || detected.isVideo,
                                    isAudio = fav.mediaType == "audio" || detected.isAudio,
                                    isImage = fav.mediaType == "image" || detected.isImage,
                                    isDocument = fav.mediaType == "document" || detected.isDocument
                                )
                                viewModel.openMediaFile(file)
                                onNavigateToPlayer(file)
                            },
                            onRemoveFavoriteClick = { fav ->
                                viewModel.removeFavorite(fav.uriString)
                                Toast.makeText(context, "Removed from favorites", Toast.LENGTH_SHORT).show()
                            },
                            onResumeHistoryClick = { hist ->
                                val detected = MimeTypeDetector.detect(hist.name)
                                val file = MediaFile(
                                    id = hist.uriString.hashCode().toLong(),
                                    uri = hist.uriString.toUri(),
                                    name = hist.name,
                                    duration = hist.duration,
                                    size = 0L,
                                    mimeType = detected.mimeType,
                                    dateAdded = hist.lastPlayedAt / 1000,
                                    isVideo = hist.mediaType == "video" || detected.isVideo,
                                    isAudio = hist.mediaType == "audio" || detected.isAudio,
                                    isImage = hist.mediaType == "image" || detected.isImage,
                                    isDocument = hist.mediaType == "document" || detected.isDocument
                                )
                                viewModel.openMediaFile(file)
                                onNavigateToPlayer(file)
                            },
                            onClearHistoryClick = {
                                viewModel.clearHistory()
                                Toast.makeText(context, "Playback history cleared", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                    !hasMediaAccess -> {
                        PermissionRequestCard(
                            isPermanentlyDenied = permissionPermanentlyDenied,
                            onGrantClick = {
                                if (permissionPermanentlyDenied) {
                                    openAppSettings(context)
                                } else {
                                    permissionState.launchMultiplePermissionRequest()
                                }
                            }
                        )
                    }
                    isLoading && mediaFiles.isEmpty() && storageFiles.isEmpty() -> {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    selectedCategoryIndex == 0 && !isSearchActive && searchQuery.isEmpty() -> {
                        GoogleFilesHomeScreen(
                            mediaFiles = mediaFiles,
                            storageScanInfo = storageScanInfo,
                            safeFilesCount = safeFiles.size,
                            favoritesCount = favorites.size,
                            onCategoryClick = { index ->
                                selectedCategoryIndex = index
                            },
                            onStorageClick = {
                                selectedCategoryIndex = 6
                                viewModel.loadStorageFiles(currentPath)
                            },
                            onSafeFolderClick = {
                                if (isSafeFolderUnlocked) {
                                    showSafeFolderModal = true
                                } else {
                                    pendingSafeFolderFiles = null
                                    showSafeFolderPinDialog = true
                                }
                            },
                            onFavoritesClick = {
                                currentBottomTab = 2
                            },
                            onCleanClick = {
                                currentBottomTab = 1
                            },
                            onRecentClick = { mediaFile ->
                                viewModel.openMediaFile(mediaFile, mediaFiles)
                                onNavigateToPlayer(mediaFile)
                            }
                        )
                    }
                    filteredFiles.isEmpty() -> {
                        EmptyMediaState(
                            searchQuery = searchQuery,
                            selectedTabName = tabNames.getOrElse(selectedCategoryIndex) { "Files" }
                        )
                    }
                    else -> {
                        Column(modifier = Modifier.fillMaxSize()) {
                            if (isStorageTab && !showBackButton) {
                                StorageOverviewCard(primaryVol = storageScanInfo.primaryVolume)
                            }

                            if (isGridView) {
                                LazyVerticalGrid(
                                    columns = GridCells.Adaptive(minSize = 150.dp),
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    items(filteredFiles, key = { it.uri.toString() }) { mediaFile ->
                                        MediaFileGridItem(
                                            mediaFile = mediaFile,
                                            isSelected = selectedFiles.contains(mediaFile),
                                            onClick = {
                                                when {
                                                    isSelectionMode -> viewModel.toggleFileSelection(mediaFile)
                                                    mediaFile.isDirectory -> viewModel.loadStorageFiles(mediaFile.absolutePath)
                                                    else -> {
                                                        viewModel.openMediaFile(mediaFile, filteredFiles)
                                                        onNavigateToPlayer(mediaFile)
                                                    }
                                                }
                                            },
                                            onLongClick = {
                                                viewModel.toggleFileSelection(mediaFile)
                                            }
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(filteredFiles, key = { it.uri.toString() }) { mediaFile ->
                                        MediaFileListItem(
                                            mediaFile = mediaFile,
                                            isSelected = selectedFiles.contains(mediaFile),
                                            onClick = {
                                                when {
                                                    isSelectionMode -> viewModel.toggleFileSelection(mediaFile)
                                                    mediaFile.isDirectory -> viewModel.loadStorageFiles(mediaFile.absolutePath)
                                                    else -> {
                                                        viewModel.openMediaFile(mediaFile, filteredFiles)
                                                        onNavigateToPlayer(mediaFile)
                                                    }
                                                }
                                            },
                                            onLongClick = {
                                                viewModel.toggleFileSelection(mediaFile)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // DELETE CONFIRMATION
    if (showDeleteConfirm) {
        val toDelete = selectedFiles.toList()
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete ${toDelete.size} file(s)?", fontWeight = FontWeight.Bold) },
            text = { Text("This permanently removes the selected files from your device.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    viewModel.deleteDirectFiles(toDelete) { deleted, needsApproval ->
                        if (needsApproval.isNotEmpty() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            try {
                                val request = android.provider.MediaStore.createDeleteRequest(context.contentResolver, needsApproval)
                                deleteLauncher.launch(androidx.activity.result.IntentSenderRequest.Builder(request.intentSender).build())
                            } catch (_: Exception) {
                                Toast.makeText(context, "Couldn't delete ${needsApproval.size} file(s)", Toast.LENGTH_SHORT).show()
                            }
                        } else if (needsApproval.isNotEmpty()) {
                            Toast.makeText(context, "Couldn't delete ${needsApproval.size} file(s)", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Deleted $deleted file(s)", Toast.LENGTH_SHORT).show()
                        }
                        viewModel.loadMediaFiles()
                        viewModel.loadStorageFiles(currentPath)
                    }
                }) { Text("Delete", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") } }
        )
    }

    // CREATE PLAYLIST MODAL
    if (showCreatePlaylistModal) {
        AlertDialog(
            onDismissRequest = {
                showCreatePlaylistModal = false
                addSelectedAfterCreate = false
            },
            title = { Text("Create New Playlist", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    label = { Text("Playlist Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_playlist_name_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = newPlaylistName.trim()
                        if (trimmed.isNotEmpty()) {
                            val shouldAdd = addSelectedAfterCreate
                            viewModel.createPlaylist(trimmed, addSelectedFiles = shouldAdd)
                            val msg = if (shouldAdd) "Created \"$trimmed\" & added files" else "Playlist created: $trimmed"
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            newPlaylistName = ""
                            addSelectedAfterCreate = false
                            showCreatePlaylistModal = false
                        }
                    },
                    modifier = Modifier.testTag("confirm_create_playlist_button")
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        addSelectedAfterCreate = false
                        showCreatePlaylistModal = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // ADD TO PLAYLIST PICKER DIALOG
    if (showAddToPlaylistDialog) {
        AlertDialog(
            onDismissRequest = { showAddToPlaylistDialog = false },
            title = { Text("Add to Playlist", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    playlists.forEach { playlist ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.addSelectedToPlaylist(playlist.id)
                                    Toast.makeText(context, "Added to \"${playlist.title}\"", Toast.LENGTH_SHORT).show()
                                    showAddToPlaylistDialog = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = playlist.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                    HorizontalDivider()
                    TextButton(
                        onClick = {
                            showAddToPlaylistDialog = false
                            addSelectedAfterCreate = true
                            showCreatePlaylistModal = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Create New Playlist", fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddToPlaylistDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // PLAYLIST DETAIL DIALOG
    selectedPlaylistForDetail?.let { playlist ->
        PlaylistDetailDialog(
            playlist = playlist,
            viewModel = viewModel,
            onPlayMedia = { file, queue ->
                viewModel.openMediaFile(file, queue)
                onNavigateToPlayer(file)
            },
            onDismiss = { selectedPlaylistForDetail = null }
        )
    }

    // SAFE FOLDER PIN DIALOG
    if (showSafeFolderPinDialog) {
        SafeFolderPinDialog(
            isPinSet = isSafeFolderPinSet,
            onPinSuccess = { pin ->
                if (!isSafeFolderPinSet) {
                    val success = viewModel.setSafeFolderPin(pin)
                    if (success) {
                        Toast.makeText(context, "Safe folder PIN set successfully", Toast.LENGTH_SHORT).show()
                        showSafeFolderPinDialog = false
                        val pending = pendingSafeFolderFiles
                        pendingSafeFolderFiles = null
                        if (!pending.isNullOrEmpty()) {
                            viewModel.moveToSafeFolder(pending) { result ->
                                onSafeMoveResult(result)
                            }
                        } else {
                            showSafeFolderModal = true
                        }
                    }
                    success
                } else {
                    val verified = viewModel.unlockSafeFolder(pin)
                    if (verified) {
                        showSafeFolderPinDialog = false
                        showSafeFolderModal = true
                    } else {
                        val waitMs = viewModel.safeFolderLockoutRemainingMs()
                        val message = if (waitMs > 0L) {
                            "Too many attempts. Try again in ${(waitMs + 999L) / 1000L}s"
                        } else {
                            "Incorrect PIN"
                        }
                        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    }
                    verified
                }
            },
            onDismiss = {
                pendingSafeFolderFiles = null
                showSafeFolderPinDialog = false
            }
        )
    }

    // SAFE FOLDER SCREEN MODAL
    if (showSafeFolderModal) {
        SafeFolderScreenModal(
            safeFiles = safeFiles,
            onLockClick = {
                viewModel.lockSafeFolder()
                showSafeFolderModal = false
                Toast.makeText(context, "Safe folder locked", Toast.LENGTH_SHORT).show()
            },
            onMoveOutClick = { targetSafeFiles ->
                viewModel.moveOutOfSafeFolder(targetSafeFiles) { count ->
                    Toast.makeText(context, "Restored $count files from Safe folder", Toast.LENGTH_SHORT).show()
                }
            },
            onDeleteClick = { safeFile ->
                viewModel.deleteSafeFilePermanently(safeFile)
                Toast.makeText(context, "Permanently deleted", Toast.LENGTH_SHORT).show()
            },
            onPlayMedia = { mediaFile ->
                viewModel.openMediaFile(mediaFile)
                onNavigateToPlayer(mediaFile)
            },
            resolveFile = { viewModel.safeFolderManager.decryptedFile(it) },
            onDismiss = {
                showSafeFolderModal = false
                viewModel.lockSafeFolder()
            }
        )
    }
}

private fun shareSelectedFiles(context: Context, files: List<MediaFile>) {
    if (files.isEmpty()) return
    try {
        val shareUris = ArrayList(files.map { resolveShareableUri(context, it.uri) })
        val intent = if (shareUris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = files.first().mimeType.ifBlank { "*/*" }
                putExtra(Intent.EXTRA_STREAM, shareUris.first())
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, shareUris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        context.startActivity(Intent.createChooser(intent, "Share ${files.size} item(s)"))
    } catch (e: Exception) {
        Toast.makeText(context, "Unable to share files: ${e.localizedMessage ?: "Error"}", Toast.LENGTH_SHORT).show()
    }
}

private fun showSafeMoveToast(context: Context, result: SafeMoveResult) {
    val message = when {
        result.moved == 0 && result.failed > 0 ->
            "Couldn't move ${result.failed} file(s) to the Safe folder. Nothing was changed."
        result.originalsRemaining > 0 ->
            "Moved ${result.moved} file(s), but ${result.originalsRemaining} original(s) couldn't be " +
                "removed from storage. Delete them manually to fully hide them."
        result.failed > 0 ->
            "Moved ${result.moved} file(s); ${result.failed} couldn't be moved."
        else -> "Moved ${result.moved} file(s) to the Safe folder"
    }
    Toast.makeText(context, message, Toast.LENGTH_LONG).show()
}

private fun openAppSettings(context: Context) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
        Toast.makeText(context, "Open Settings > Apps > Vivilo > Permissions", Toast.LENGTH_LONG).show()
    }
}
