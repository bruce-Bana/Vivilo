package com.vivilo.media.ui.screens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.vivilo.media.data.MediaFile
import com.vivilo.media.data.MimeTypeDetector
import com.vivilo.media.data.StorageUtils
import com.vivilo.media.ui.theme.AccentDoc
import com.vivilo.media.ui.theme.LocalAppPreferences
import com.vivilo.media.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    uriString: String,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val playbackManager = viewModel.playbackManager
    val dbRepo = viewModel.dbRepo
    val prefs = LocalAppPreferences.current

    // Navigation already URL-decodes path arguments. Decoding a second time turned "%20"/"%25" in
    // file names into raw spaces/percent signs, so the URI no longer matched the playing file
    // (playback restarted) and files with '%' in their name failed to open. Only decode when the
    // value still looks encoded (no scheme separator).
    val decodedUri = remember(uriString) {
        if (uriString.contains("://")) uriString else Uri.decode(uriString)
    }
    val resolvedFile = remember(decodedUri) { viewModel.resolveMediaFile(decodedUri) }
    val viewerQueue by viewModel.activeViewerQueue.collectAsState()

    val fallbackName = remember(decodedUri) {
        val raw = decodedUri.substringAfterLast('/').substringBefore('?')
        raw.ifEmpty { "Media File" }
    }
    val fallbackType = remember(fallbackName, decodedUri) {
        val detected = MimeTypeDetector.detect(fallbackName)
        val uriIsVideo = decodedUri.contains("/video/", ignoreCase = true)
        val uriIsImage = decodedUri.contains("/images/", ignoreCase = true)
        val uriIsAudio = decodedUri.contains("/audio/", ignoreCase = true)
        when {
            detected.isVideo || uriIsVideo -> Triple(true, false, false)
            detected.isImage || uriIsImage -> Triple(false, false, true)
            detected.isAudio || uriIsAudio -> Triple(false, true, false)
            else -> Triple(false, false, false)
        }
    }

    val currentFile by playbackManager.currentFile.collectAsState()
    val activeFile = resolvedFile ?: currentFile?.takeIf { it.uri.toString() == decodedUri }
    val displayName = activeFile?.name ?: fallbackName
    val isVideo = activeFile?.isVideo ?: fallbackType.first
    val isImage = activeFile?.isImage ?: fallbackType.third
    val isDocument = activeFile?.isDocument ?: (!isVideo && !isImage && !fallbackType.second)
    val isAudio = !isVideo && !isImage && !isDocument

    val isPlaying by playbackManager.isPlaying.collectAsState()
    val isBuffering by playbackManager.isBuffering.collectAsState()
    val playerError by playbackManager.playerError.collectAsState()
    val currentPosition by playbackManager.currentPosition.collectAsState()
    val duration by playbackManager.duration.collectAsState()
    val speed by playbackManager.speed.collectAsState()
    val isShuffle by playbackManager.isShuffle.collectAsState()
    val repeatMode by playbackManager.repeatMode.collectAsState()
    val eqPreset by playbackManager.equalizerPreset.collectAsState()
    val eqBandLevels by playbackManager.equalizerBandLevels.collectAsState()
    val aspectRatioMode by playbackManager.aspectRatioMode.collectAsState()

    var showControls by remember { mutableStateOf(true) }
    var isControlsLocked by remember { mutableStateOf(false) }
    var showEqModal by remember { mutableStateOf(false) }
    var showInfoModal by remember { mutableStateOf(false) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPosition by remember { mutableFloatStateOf(0f) }

    var gestureHint by remember { mutableStateOf<String?>(null) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showSleepDialog by remember { mutableStateOf(false) }
    val sleepEndsAt by playbackManager.sleepTimerEndsAt.collectAsState()
    val isLandscape = androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
        android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val subtitlePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { picked ->
        if (picked != null) {
            val name = context.contentResolver.query(picked, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: picked.lastPathSegment.orEmpty()
            playbackManager.addSubtitle(picked, name)
            Toast.makeText(context, "Subtitles loaded", Toast.LENGTH_SHORT).show()
        }
    }
    var doubleTapFeedback by remember { mutableStateOf<String?>(null) }
    var doubleTapSide by remember { mutableStateOf<Boolean?>(null) }

    val activeUriStr = (activeFile?.uri?.toString()) ?: decodedUri
    val isFavorite by remember(activeUriStr) {
        dbRepo.isFavorite(activeUriStr)
    }.collectAsState(initial = false)

    // Only load into ExoPlayer when it's actually video or audio
    LaunchedEffect(decodedUri, isVideo, isAudio) {
        if ((isVideo || isAudio) && playbackManager.currentFile.value?.uri?.toString() != decodedUri) {
            val mediaFile = activeFile ?: MediaFile(
                id = decodedUri.hashCode().toLong(),
                uri = decodedUri.toUri(),
                name = displayName,
                duration = 0L,
                size = 0L,
                mimeType = if (isVideo) "video/*" else "audio/*",
                dateAdded = System.currentTimeMillis() / 1000,
                isVideo = isVideo,
                isAudio = isAudio,
                isImage = false,
                isDocument = false
            )
            playbackManager.playFile(mediaFile)
        }
    }

    LaunchedEffect(showControls, isPlaying, isControlsLocked) {
        if (isVideo && showControls && isPlaying && !isControlsLocked) {
            delay(4000L)
            showControls = false
        }
    }

    val appUsesLightBars = MaterialTheme.colorScheme.background.luminance() > 0.5f
    DisposableEffect(isVideo, isImage) {
        val activity = context as? Activity
        val window = activity?.window
        if (window != null && (isVideo || isImage)) {
            val insetsController = WindowCompat.getInsetsController(window, window.decorView)
            // The image and video viewers are always black: use light status/navigation icons so
            // they stay visible even when the app itself is in the Light theme.
            insetsController.isAppearanceLightStatusBars = false
            insetsController.isAppearanceLightNavigationBars = false
            if (isVideo) {
                playbackManager.videoScreenVisible = true
                insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                insetsController.hide(WindowInsetsCompat.Type.statusBars())
            }
        }
        onDispose {
            playbackManager.videoScreenVisible = false
            activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            if (window != null) {
                val lp = window.attributes
                lp.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                window.attributes = lp
                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                insetsController.show(WindowInsetsCompat.Type.statusBars())
                insetsController.isAppearanceLightStatusBars = appUsesLightBars
                insetsController.isAppearanceLightNavigationBars = appUsesLightBars
            }
        }
    }

    val toggleFavAction = {
        val targetUri = activeUriStr
        val targetName = currentFile?.name ?: displayName
        val mediaType = when {
            isVideo -> "video"
            isImage -> "image"
            isDocument -> "document"
            else -> "audio"
        }
        coroutineScope.launch {
            dbRepo.toggleFavorite(
                uriString = targetUri,
                name = targetName,
                mediaType = mediaType,
                duration = activeFile?.duration ?: duration,
                size = activeFile?.size ?: 0L,
                isFav = isFavorite
            )
            Toast.makeText(
                context,
                if (isFavorite) "Removed from favorites" else "Added to favorites",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    val displayPosition = if (isScrubbing) (scrubPosition * duration).toLong() else currentPosition

    when {
        isImage -> {
            val imageQueue = remember(viewerQueue, activeFile) {
                val imgs = viewerQueue.filter { it.isImage }
                if (imgs.isNotEmpty()) imgs else listOfNotNull(activeFile)
            }
            var currentImgIdx by remember(decodedUri, imageQueue) {
                mutableIntStateOf(imageQueue.indexOfFirst { it.uri.toString() == decodedUri }.coerceAtLeast(0))
            }
            val shownImage = imageQueue.getOrNull(currentImgIdx) ?: activeFile
            val shownUri = shownImage?.uri ?: decodedUri.toUri()
            val shownName = shownImage?.name ?: displayName

            var scale by remember(shownUri) { mutableFloatStateOf(1f) }
            var offsetX by remember(shownUri) { mutableFloatStateOf(0f) }
            var offsetY by remember(shownUri) { mutableFloatStateOf(0f) }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(shownUri) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newScale = (scale * zoom).coerceIn(1f, 5f)
                                scale = newScale
                                if (newScale > 1f) {
                                    offsetX += pan.x
                                    offsetY += pan.y
                                } else {
                                    offsetX = 0f
                                    offsetY = 0f
                                }
                            }
                        }
                        .pointerInput(shownUri) {
                            detectTapGestures(
                                onDoubleTap = {
                                    if (scale > 1.05f) {
                                        scale = 1f
                                        offsetX = 0f
                                        offsetY = 0f
                                    } else {
                                        scale = 2.5f
                                    }
                                },
                                onTap = { showControls = !showControls }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = shownUri,
                        contentDescription = shownName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetX,
                                translationY = offsetY
                            )
                    )
                }

                AnimatedVisibility(
                    visible = showControls,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.55f))
                                .statusBarsPadding()
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .align(Alignment.TopCenter),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                IconButton(
                                    onClick = onNavigateBack,
                                    modifier = Modifier.testTag("player_back_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Back",
                                        tint = Color.White
                                    )
                                }
                                Text(
                                    text = shownName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { toggleFavAction() },
                                    modifier = Modifier.testTag("player_favorite_button")
                                ) {
                                    Icon(
                                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "Favorite",
                                        tint = if (isFavorite) Color(0xFFFFB800) else Color.White
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        shareSingleFile(context, shownUri, shownImage?.mimeType ?: "image/*")
                                    }
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                                }
                                IconButton(
                                    onClick = { showInfoModal = true },
                                    modifier = Modifier.testTag("player_info_button")
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = "Info", tint = Color.White)
                                }
                            }
                        }

                        if (imageQueue.size > 1) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.55f))
                                    .navigationBarsPadding()
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                                    .align(Alignment.BottomCenter),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = {
                                        if (currentImgIdx > 0) currentImgIdx--
                                    },
                                    enabled = currentImgIdx > 0
                                ) {
                                    Icon(
                                        Icons.Default.ChevronLeft,
                                        contentDescription = "Previous image",
                                        tint = if (currentImgIdx > 0) Color.White else Color.White.copy(alpha = 0.3f)
                                    )
                                }
                                Text(
                                    text = "${currentImgIdx + 1} / ${imageQueue.size}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold
                                )
                                IconButton(
                                    onClick = {
                                        if (currentImgIdx < imageQueue.lastIndex) currentImgIdx++
                                    },
                                    enabled = currentImgIdx < imageQueue.lastIndex
                                ) {
                                    Icon(
                                        Icons.Default.ChevronRight,
                                        contentDescription = "Next image",
                                        tint = if (currentImgIdx < imageQueue.lastIndex) Color.White else Color.White.copy(alpha = 0.3f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        isDocument -> {
            val docUri = activeFile?.uri ?: decodedUri.toUri()
            val ext = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            val isTextReadable = ext in setOf("txt", "log", "md", "csv", "json", "xml", "rtf")
            var textPreview by remember(docUri) { mutableStateOf<String?>(null) }
            var textError by remember(docUri) { mutableStateOf<String?>(null) }

            LaunchedEffect(docUri, isTextReadable) {
                if (isTextReadable) {
                    withContext(Dispatchers.IO) {
                        try {
                            val stream = context.contentResolver.openInputStream(docUri)
                                ?: activeFile?.absolutePath?.let { File(it).takeIf { f -> f.exists() }?.inputStream() }
                            if (stream != null) {
                                stream.bufferedReader().use { reader ->
                                    val buffer = CharArray(64 * 1024)
                                    val read = reader.read(buffer)
                                    textPreview = if (read > 0) String(buffer, 0, read) else "(Empty document)"
                                }
                            } else {
                                textError = "Could not open document stream."
                            }
                        } catch (e: Exception) {
                            textError = e.localizedMessage ?: "Failed to read document"
                        }
                    }
                }
            }

            Scaffold(
                topBar = {
                    @kotlin.OptIn(ExperimentalMaterial3Api::class)
                    TopAppBar(
                        title = {
                            Text(
                                text = displayName,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = onNavigateBack,
                                modifier = Modifier.testTag("player_back_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { toggleFavAction() },
                                modifier = Modifier.testTag("player_favorite_button")
                            ) {
                                Icon(
                                    imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "Favorite",
                                    tint = if (isFavorite) Color(0xFFFFB800) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = {
                                shareSingleFile(context, docUri, activeFile?.mimeType ?: "*/*")
                            }) {
                                Icon(Icons.Default.Share, contentDescription = "Share")
                            }
                        }
                    )
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                    ) {
                        Row(
                            modifier = Modifier.padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(AccentDoc.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = null,
                                    tint = AccentDoc,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = displayName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${activeFile?.mimeType ?: "Document"} • ${StorageUtils.formatSize(activeFile?.size ?: 0L)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            openFileExternally(context, docUri, activeFile?.mimeType ?: "*/*")
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Open with External App", fontWeight = FontWeight.SemiBold)
                    }

                    if (isTextReadable) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Preview", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                when {
                                    textError != null -> Text(textError ?: "", color = MaterialTheme.colorScheme.error)
                                    textPreview != null -> Text(
                                        text = textPreview ?: "",
                                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                                    )
                                    else -> CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        isVideo -> {
            // ==========================================
            // CINEMATIC VIDEO PLAYER
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .pointerInput(isControlsLocked) {
                        detectTapGestures(
                            onDoubleTap = { offset ->
                                if (!isControlsLocked) {
                                    val isRight = offset.x > size.width / 2
                                    doubleTapSide = isRight
                                    if (isRight) {
                                        val newPos = (playbackManager.currentPosition.value + 10000L).coerceAtMost(duration)
                                        playbackManager.seekTo(newPos)
                                        doubleTapFeedback = "+10s"
                                    } else {
                                        val newPos = (playbackManager.currentPosition.value - 10000L).coerceAtLeast(0L)
                                        playbackManager.seekTo(newPos)
                                        doubleTapFeedback = "-10s"
                                    }
                                }
                            },
                            onTap = {
                                if (!isControlsLocked) {
                                    showControls = !showControls
                                }
                            }
                        )
                    }
                    .pointerInput(isControlsLocked) {
                        if (isControlsLocked) return@pointerInput
                        var adjustBrightness = true
                        androidx.compose.foundation.gestures.detectVerticalDragGestures(
                            onDragStart = { adjustBrightness = it.x < size.width / 2f },
                            onVerticalDrag = { _, dragY ->
                                val delta = -dragY / size.height.toFloat()
                                if (adjustBrightness) {
                                    val window = (context as? Activity)?.window
                                    if (window != null) {
                                        val lp = window.attributes
                                        val current = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                        lp.screenBrightness = (current + delta).coerceIn(0.02f, 1f)
                                        window.attributes = lp
                                        gestureHint = "Brightness ${(lp.screenBrightness * 100).toInt()}%"
                                    }
                                } else {
                                    val newVol = (playbackManager.volume.value + delta).coerceIn(0f, 1f)
                                    playbackManager.setVolume(newVol)
                                    gestureHint = "Volume ${(newVol * 100).toInt()}%"
                                }
                            }
                        )
                    }
            ) {
                if (showSleepDialog) {
                    androidx.compose.material3.AlertDialog(
                        onDismissRequest = { showSleepDialog = false },
                        title = { Text("Sleep timer") },
                        text = {
                            Column {
                                listOf(15, 30, 45, 60, 0).forEach { minutes ->
                                    androidx.compose.material3.TextButton(
                                        onClick = {
                                            playbackManager.setSleepTimer(minutes)
                                            showSleepDialog = false
                                            Toast.makeText(
                                                context,
                                                if (minutes == 0) "Sleep timer off" else "Playback will pause in $minutes min",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text(if (minutes == 0) "Turn off" else "$minutes minutes") }
                                }
                            }
                        },
                        confirmButton = {
                            androidx.compose.material3.TextButton(onClick = { showSleepDialog = false }) { Text("Close") }
                        }
                    )
                }
                LaunchedEffect(gestureHint) {
                    if (gestureHint != null) {
                        delay(800L)
                        gestureHint = null
                    }
                }
                gestureHint?.let { hint ->
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Black.copy(alpha = 0.7f),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .statusBarsPadding()
                            .padding(top = 24.dp)
                    ) {
                        Text(
                            text = hint,
                            color = Color.White,
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = playbackManager.exoPlayer
                            useController = false
                            resizeMode = when (aspectRatioMode) {
                                1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                        }
                    },
                    update = { view ->
                        // Without this the screen timed out in the middle of a movie.
                        view.keepScreenOn = isPlaying
                        view.player = playbackManager.exoPlayer
                        view.resizeMode = when (aspectRatioMode) {
                            1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        }
                    }
                )

                LaunchedEffect(doubleTapFeedback) {
                    if (doubleTapFeedback != null) {
                        delay(750L)
                        doubleTapFeedback = null
                        doubleTapSide = null
                    }
                }

                AnimatedVisibility(
                    visible = doubleTapFeedback != null,
                    enter = fadeIn() + scaleIn(),
                    exit = fadeOut() + scaleOut(),
                    modifier = Modifier
                        .align(if (doubleTapSide == true) Alignment.CenterEnd else Alignment.CenterStart)
                        .padding(horizontal = 48.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.65f),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = if (doubleTapSide == true) Icons.Default.Forward10 else Icons.Default.Replay10,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = doubleTapFeedback ?: "",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                if (isBuffering && playerError == null) {
                    Box(
                        modifier = Modifier.align(Alignment.Center),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }

                if (playerError != null) {
                    PlayerErrorOverlay(
                        errorMessage = playerError ?: "Unable to play this media file.",
                        onGoBack = onNavigateBack,
                        onRetry = { playbackManager.retry() },
                        modifier = Modifier.align(Alignment.Center)
                    )
                }

                if (isControlsLocked) {
                    Surface(
                        onClick = {
                            isControlsLocked = false
                            showControls = true
                            Toast.makeText(context, "Controls Unlocked", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(24.dp),
                        color = Color.Black.copy(alpha = 0.65f),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .statusBarsPadding()
                            .padding(24.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Unlock",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Locked",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                AnimatedVisibility(
                    visible = showControls && !isControlsLocked && playerError == null,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.6f),
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.75f)
                                    )
                                )
                            )
                            .statusBarsPadding()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        // TOP BAR
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                IconButton(
                                    onClick = onNavigateBack,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("player_back_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Back",
                                        tint = Color.White
                                    )
                                }

                                Text(
                                    text = currentFile?.name ?: displayName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.White.copy(alpha = 0.15f),
                                    onClick = {
                                        val mode = playbackManager.cycleAspectRatioMode()
                                        val modeName = when (mode) {
                                            1 -> "Fill / Zoom"
                                            2 -> "Stretch 16:9"
                                            else -> "Fit Screen"
                                        }
                                        Toast.makeText(context, "Aspect: $modeName", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(horizontal = 10.dp)
                                    ) {
                                        Text(
                                            text = when (aspectRatioMode) {
                                                1 -> "Fill"
                                                2 -> "16:9"
                                                else -> "Fit"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.White.copy(alpha = 0.15f),
                                    onClick = {
                                        val nextSpeed = when (speed) {
                                            0.75f -> 1.0f
                                            1.0f -> 1.25f
                                            1.25f -> 1.5f
                                            1.5f -> 2.0f
                                            else -> 0.75f
                                        }
                                        playbackManager.setSpeed(nextSpeed)
                                    },
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(horizontal = 10.dp)
                                    ) {
                                        Text(
                                            text = "${speed}x",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { toggleFavAction() },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("player_favorite_button")
                                ) {
                                    Icon(
                                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "Favorite",
                                        tint = if (isFavorite) Color(0xFFFFB800) else Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        isControlsLocked = true
                                        showControls = false
                                        Toast.makeText(context, "Screen controls locked", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LockOpen,
                                        contentDescription = "Lock",
                                        tint = Color.White.copy(alpha = 0.85f),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { showInfoModal = true },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("player_info_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "Info",
                                        tint = Color.White.copy(alpha = 0.85f),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Box {
                                    IconButton(
                                        onClick = { showMoreMenu = true },
                                        modifier = Modifier.size(48.dp).testTag("player_more_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MoreVert,
                                            contentDescription = "More options",
                                            tint = Color.White.copy(alpha = 0.85f),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    androidx.compose.material3.DropdownMenu(
                                        expanded = showMoreMenu,
                                        onDismissRequest = { showMoreMenu = false }
                                    ) {
                                        androidx.compose.material3.DropdownMenuItem(
                                            text = { Text(if (isLandscape) "Portrait" else "Fullscreen (landscape)") },
                                            leadingIcon = { Icon(Icons.Default.ScreenRotation, contentDescription = null) },
                                            onClick = {
                                                showMoreMenu = false
                                                (context as? Activity)?.requestedOrientation = if (isLandscape) {
                                                    android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                                } else {
                                                    android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                                }
                                            }
                                        )
                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                            androidx.compose.material3.DropdownMenuItem(
                                                text = { Text("Picture-in-picture") },
                                                leadingIcon = { Icon(Icons.Default.PictureInPictureAlt, contentDescription = null) },
                                                onClick = {
                                                    showMoreMenu = false
                                                    runCatching {
                                                        (context as? Activity)?.enterPictureInPictureMode(
                                                            android.app.PictureInPictureParams.Builder()
                                                                .setAspectRatio(android.util.Rational(16, 9))
                                                                .build()
                                                        )
                                                    }
                                                }
                                            )
                                        }
                                        androidx.compose.material3.DropdownMenuItem(
                                            text = { Text("Add subtitles") },
                                            leadingIcon = { Icon(Icons.Default.Subtitles, contentDescription = null) },
                                            onClick = {
                                                showMoreMenu = false
                                                subtitlePicker.launch(arrayOf("*/*"))
                                            }
                                        )
                                        androidx.compose.material3.DropdownMenuItem(
                                            text = { Text(if (sleepEndsAt != null) "Sleep timer (on)" else "Sleep timer") },
                                            leadingIcon = { Icon(Icons.Default.Timer, contentDescription = null) },
                                            onClick = {
                                                showMoreMenu = false
                                                showSleepDialog = true
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // CENTER CONTROLS
                        Row(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalArrangement = Arrangement.spacedBy(28.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.size(48.dp),
                                onClick = {
                                    val newPos = (currentPosition - 10000L).coerceAtLeast(0L)
                                    playbackManager.seekTo(newPos)
                                }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Replay10,
                                        contentDescription = "Rewind 10s",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            }

                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary,
                                shadowElevation = 8.dp,
                                modifier = Modifier.size(68.dp),
                                onClick = { playbackManager.togglePlayPause() }
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("play_pause_button")
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = Color.White,
                                        modifier = Modifier.size(38.dp)
                                    )
                                }
                            }

                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.size(48.dp),
                                onClick = {
                                    val newPos = (currentPosition + 10000L).coerceAtMost(duration)
                                    playbackManager.seekTo(newPos)
                                }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Forward10,
                                        contentDescription = "Forward 10s",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            }
                        }

                        // BOTTOM SCRUBBER
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.Black.copy(alpha = 0.55f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                val progress = if (duration > 0) {
                                    (displayPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                                } else 0f

                                Slider(
                                    value = progress,
                                    onValueChange = { newProg ->
                                        isScrubbing = true
                                        scrubPosition = newProg
                                    },
                                    onValueChangeFinished = {
                                        val targetMs = (scrubPosition * duration).toLong()
                                        playbackManager.seekTo(targetMs)
                                        isScrubbing = false
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(28.dp),
                                    colors = SliderDefaults.colors(
                                        thumbColor = MaterialTheme.colorScheme.primary,
                                        activeTrackColor = MaterialTheme.colorScheme.primary,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                    )
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = formatMediaTime(displayPosition),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontWeight = FontWeight.Medium
                                    )

                                    Text(
                                        text = formatMediaTime(duration),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        else -> {
            // ==========================================
            // AUDIO STUDIO PLAYER
            // ==========================================
            val infiniteTransition = rememberInfiniteTransition(label = "audio_rotation")
            val vinylRotation by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 360f,
                animationSpec = infiniteRepeatable(
                    animation = tween(12000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "vinyl"
            )
            val baseBars = remember {
                listOf(0.35f, 0.6f, 0.9f, 0.5f, 0.8f, 1.0f, 0.7f, 0.45f, 0.85f, 0.55f, 0.95f, 0.4f, 0.75f, 0.5f)
            }
            val animatedBarFactors = baseBars.mapIndexed { index, target ->
                val wave by infiniteTransition.animateFloat(
                    initialValue = 0.2f,
                    targetValue = target,
                    animationSpec = infiniteRepeatable(
                        animation = tween(420 + (index * 60) % 480, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "bar_$index"
                )
                wave
            }

            Scaffold(
                containerColor = MaterialTheme.colorScheme.surface,
                topBar = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.testTag("player_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "NOW PLAYING",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 1.5.sp
                            )
                            Text(
                                text = "Vivilo Audio Studio",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row {
                            IconButton(
                                onClick = { showEqModal = true },
                                modifier = Modifier.testTag("player_eq_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Equalizer,
                                    contentDescription = "Equalizer",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(
                                onClick = { showInfoModal = true },
                                modifier = Modifier.testTag("player_info_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Info",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // VINYL / ARTWORK HERO CARD
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                modifier = Modifier
                                    .size(240.dp)
                                    .scale(if (isPlaying && !prefs.reduceMotion) 1.05f else 1.0f),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = if (isPlaying) 0.18f else 0.08f)
                            ) {}

                            Surface(
                                modifier = Modifier
                                    .size(220.dp)
                                    .rotate(if (isPlaying && !prefs.reduceMotion) vinylRotation else 0f),
                                shape = CircleShape,
                                color = Color(0xFF1E2124),
                                shadowElevation = 12.dp
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Surface(
                                        modifier = Modifier.size(160.dp),
                                        shape = CircleShape,
                                        color = Color(0xFF16181A)
                                    ) {}
                                    Surface(
                                        modifier = Modifier.size(100.dp),
                                        shape = CircleShape,
                                        color = Color(0xFF262A2E)
                                    ) {}

                                    Surface(
                                        modifier = Modifier.size(68.dp),
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primary
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.MusicNote,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(32.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // TITLE & METADATA
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = currentFile?.name ?: displayName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                                ) {
                                    Text(
                                        text = "HD AUDIO",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                Text(
                                    text = "Preset: $eqPreset",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // SOUND WAVE VISUALIZER
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(36.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            animatedBarFactors.forEachIndexed { idx, waveVal ->
                                val barHeight = when {
                                    isPlaying && !prefs.reduceMotion -> waveVal
                                    isPlaying -> baseBars[idx]
                                    else -> 0.2f
                                }
                                Box(
                                    modifier = Modifier
                                        .width(4.dp)
                                        .fillMaxHeight(barHeight)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = if (isPlaying) 0.85f else 0.3f))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // SCRUBBER & TIMELINE
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val progress = if (duration > 0) {
                                (displayPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                            } else 0f

                            Slider(
                                value = progress,
                                onValueChange = { newProg ->
                                    isScrubbing = true
                                    scrubPosition = newProg
                                },
                                onValueChangeFinished = {
                                    val targetMs = (scrubPosition * duration).toLong()
                                    playbackManager.seekTo(targetMs)
                                    isScrubbing = false
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = SliderDefaults.colors(
                                    thumbColor = MaterialTheme.colorScheme.primary,
                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                    inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = formatMediaTime(displayPosition),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = formatMediaTime(duration),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // PLAYBACK CONTROLS ROW
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { playbackManager.toggleShuffle() }) {
                                Icon(
                                    imageVector = Icons.Default.Shuffle,
                                    contentDescription = "Shuffle",
                                    tint = if (isShuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                )
                            }

                            IconButton(
                                onClick = { playbackManager.playPrevious() },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipPrevious,
                                    contentDescription = "Previous",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary,
                                shadowElevation = 8.dp,
                                modifier = Modifier.size(68.dp),
                                onClick = { playbackManager.togglePlayPause() }
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("play_pause_button")
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = Color.White,
                                        modifier = Modifier.size(38.dp)
                                    )
                                }
                            }

                            IconButton(
                                onClick = { playbackManager.playNext() },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Next",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            IconButton(onClick = { playbackManager.cycleRepeatMode() }) {
                                Icon(
                                    imageVector = when (repeatMode) {
                                        Player.REPEAT_MODE_ONE -> Icons.Default.RepeatOne
                                        else -> Icons.Default.Repeat
                                    },
                                    contentDescription = "Repeat",
                                    tint = if (repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // BOTTOM ACTION CHIPS
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = speed != 1.0f,
                                onClick = {
                                    val next = when (speed) {
                                        1.0f -> 1.25f
                                        1.25f -> 1.5f
                                        1.5f -> 2.0f
                                        else -> 1.0f
                                    }
                                    playbackManager.setSpeed(next)
                                },
                                label = { Text("${speed}x") },
                                leadingIcon = {
                                    Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            )

                            FilterChip(
                                selected = isFavorite,
                                onClick = { toggleFavAction() },
                                label = { Text(if (isFavorite) "Favorited" else "Favorite") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = null,
                                        tint = if (isFavorite) Color(0xFFFFB800) else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.testTag("player_favorite_button")
                            )

                            FilterChip(
                                selected = eqPreset != "Normal",
                                onClick = { showEqModal = true },
                                label = { Text("EQ") },
                                leadingIcon = {
                                    Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    if (playerError != null) {
                        PlayerErrorOverlay(
                            errorMessage = playerError ?: "Unable to play this audio file.",
                            onGoBack = onNavigateBack,
                            onRetry = { playbackManager.retry() },
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }
            }
        }
    }

    // EQUALIZER MODAL
    if (showEqModal) {
        AlertDialog(
            onDismissRequest = { showEqModal = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Equalizer, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Sound Equalizer", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Acoustic Presets", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    val presets = listOf("Normal", "Bass Boost", "Vocal", "Rock", "Pop", "Jazz", "Electronic", "Classical")
                    presets.chunked(2).forEach { row ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { preset ->
                                FilterChip(
                                    selected = eqPreset == preset,
                                    onClick = {
                                        playbackManager.setEqualizerPreset(preset)
                                        Toast.makeText(context, "$preset preset enabled", Toast.LENGTH_SHORT).show()
                                    },
                                    label = { Text(preset, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Text("Frequency Bands ($eqPreset)", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(96.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        eqBandLevels.forEachIndexed { idx, targetVal ->
                            val animatedBar by animateFloatAsState(
                                targetValue = targetVal.coerceIn(0.15f, 1.0f),
                                label = "eq_band_$idx"
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(
                                    modifier = Modifier
                                        .width(18.dp)
                                        .weight(1f),
                                    contentAlignment = Alignment.BottomCenter
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(18.dp)
                                            .fillMaxHeight(animatedBar)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                }
                                Text(
                                    text = when (idx) {
                                        0 -> "60Hz"
                                        1 -> "230Hz"
                                        2 -> "910Hz"
                                        3 -> "3.6kHz"
                                        else -> "14kHz"
                                    },
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showEqModal = false }) {
                    Text("Apply & Close")
                }
            }
        )
    }

    // MEDIA PROPERTIES INFO MODAL
    if (showInfoModal) {
        AlertDialog(
            onDismissRequest = { showInfoModal = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Media Details", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    InfoRow("Filename", currentFile?.name ?: displayName)
                    InfoRow(
                        "Type",
                        when {
                            isVideo -> "Video Media"
                            isImage -> "Image"
                            isDocument -> "Document"
                            else -> "Audio Stream"
                        }
                    )
                    if (activeFile != null && activeFile.size > 0L) {
                        InfoRow("File Size", StorageUtils.formatSize(activeFile.size))
                    }
                    if (isVideo || isAudio) {
                        InfoRow("Duration", formatMediaTime(duration.takeIf { it > 0 } ?: (activeFile?.duration ?: 0L)))
                        InfoRow("Playback Speed", "${speed}x")
                        if (isAudio) {
                            InfoRow("Equalizer", eqPreset)
                        }
                    }
                    InfoRow("Source URI", decodedUri)
                }
            },
            confirmButton = {
                TextButton(onClick = { showInfoModal = false }) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun PlayerErrorOverlay(
    errorMessage: String,
    onGoBack: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(0.9f),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.size(52.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
            Text(
                text = "Playback Error",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(top = 8.dp)
            ) {
                OutlinedButton(
                    onClick = onGoBack,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Go Back")
                }
                Button(
                    onClick = onRetry,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Retry")
                }
            }
        }
    }
}

private fun shareSingleFile(context: Context, uri: Uri, mimeType: String) {
    try {
        val shareUri = resolveShareableUri(context, uri)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.ifBlank { "*/*" }
            putExtra(Intent.EXTRA_STREAM, shareUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share file"))
    } catch (e: Exception) {
        Toast.makeText(context, "Unable to share file: ${e.localizedMessage ?: "Error"}", Toast.LENGTH_SHORT).show()
    }
}

private fun openFileExternally(context: Context, uri: Uri, mimeType: String) {
    try {
        val viewUri = resolveShareableUri(context, uri)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(viewUri, mimeType.ifBlank { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Open with"))
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, "No app installed to open this file type", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open file: ${e.localizedMessage ?: "Error"}", Toast.LENGTH_SHORT).show()
    }
}

fun resolveShareableUri(context: Context, uri: Uri): Uri {
    if (uri.scheme == "file") {
        val path = uri.path ?: return uri
        val file = File(path)
        if (file.exists()) {
            return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }
    }
    return uri
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

private fun formatMediaTime(millis: Long): String {
    if (millis <= 0) return "00:00"
    val totalSeconds = millis / 1000
    val seconds = totalSeconds % 60
    val minutes = (totalSeconds / 60) % 60
    val hours = totalSeconds / 3600
    return if (hours > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }
}
