package com.vivilo.media.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.vivilo.media.data.MediaFile
import com.vivilo.media.data.MimeTypeDetector
import com.vivilo.media.data.StorageUtils
import com.vivilo.media.data.db.SafeFileEntity
import com.vivilo.media.ui.theme.AccentAudio
import com.vivilo.media.ui.theme.AccentDoc
import java.io.File

@Composable
fun SafeFolderPinDialog(
    isPinSet: Boolean,
    onPinSuccess: (String) -> Boolean,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var isConfirmingStep by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (!isPinSet) {
                            if (isConfirmingStep) "Confirm 4-Digit PIN" else "Set 4-Digit PIN"
                        } else {
                            "Enter Safe Folder PIN"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (!isPinSet) {
                            "Choose a 4-digit PIN to protect your private files"
                        } else {
                            "Enter your PIN to access your protected files"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }

                // PIN Dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val currentPin = if (isConfirmingStep) confirmPin else pin
                    for (i in 0 until 4) {
                        val isFilled = i < currentPin.length
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isFilled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.25f)
                                )
                        )
                    }
                }

                errorMessage?.let { err ->
                    Text(
                        text = err,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Numeric Keypad
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val keys = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("C", "0", "⌫")
                    )

                    keys.forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            row.forEach { key ->
                                KeypadButton(
                                    label = key,
                                    onClick = {
                                        errorMessage = null
                                        when (key) {
                                            "C" -> {
                                                if (isConfirmingStep) confirmPin = "" else pin = ""
                                            }
                                            "⌫" -> {
                                                if (isConfirmingStep) {
                                                    if (confirmPin.isNotEmpty()) confirmPin = confirmPin.dropLast(1)
                                                } else {
                                                    if (pin.isNotEmpty()) pin = pin.dropLast(1)
                                                }
                                            }
                                            else -> {
                                                if (!isPinSet) {
                                                    if (!isConfirmingStep) {
                                                        if (pin.length < 4) {
                                                            pin += key
                                                            if (pin.length == 4) {
                                                                isConfirmingStep = true
                                                            }
                                                        }
                                                    } else {
                                                        if (confirmPin.length < 4) {
                                                            confirmPin += key
                                                            if (confirmPin.length == 4) {
                                                                if (pin == confirmPin) {
                                                                    if (!onPinSuccess(pin)) {
                                                                        errorMessage = "Could not save PIN. Try again."
                                                                        confirmPin = ""
                                                                        pin = ""
                                                                        isConfirmingStep = false
                                                                    }
                                                                } else {
                                                                    errorMessage = "PINs do not match. Try again."
                                                                    confirmPin = ""
                                                                    pin = ""
                                                                    isConfirmingStep = false
                                                                }
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if (pin.length < 4) {
                                                        pin += key
                                                        if (pin.length == 4) {
                                                            val ok = onPinSuccess(pin)
                                                            if (!ok) {
                                                                errorMessage = "Incorrect PIN. Try again."
                                                                pin = ""
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pin_cancel_button")
                ) {
                    Text("Cancel", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun KeypadButton(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        modifier = Modifier
            .size(62.dp)
            .testTag("pin_key_$label")
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SafeFolderScreenModal(
    safeFiles: List<SafeFileEntity>,
    onLockClick: () -> Unit,
    onMoveOutClick: (List<SafeFileEntity>) -> Unit,
    onDeleteClick: (SafeFileEntity) -> Unit,
    onPlayMedia: (MediaFile) -> Unit,
    resolveFile: suspend (SafeFileEntity) -> File?,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var selectedSafeFiles by remember { mutableStateOf(setOf<SafeFileEntity>()) }
    val isSelectionMode = selectedSafeFiles.isNotEmpty()

    BackHandler {
        if (isSelectionMode) {
            selectedSafeFiles = emptySet()
        } else {
            onDismiss()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        IconButton(
                            onClick = {
                                if (isSelectionMode) {
                                    selectedSafeFiles = emptySet()
                                } else {
                                    onDismiss()
                                }
                            },
                            modifier = Modifier.testTag("safe_folder_back_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = if (isSelectionMode) "${selectedSafeFiles.size} selected" else "Safe folder",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (isSelectionMode) {
                            IconButton(
                                onClick = {
                                    onMoveOutClick(selectedSafeFiles.toList())
                                    selectedSafeFiles = emptySet()
                                },
                                modifier = Modifier.testTag("safe_folder_move_out_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.DriveFileMove, contentDescription = "Move out", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(
                                onClick = {
                                    selectedSafeFiles.forEach { onDeleteClick(it) }
                                    selectedSafeFiles = emptySet()
                                },
                                modifier = Modifier.testTag("safe_folder_delete_button")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                            }
                        } else {
                            Button(
                                onClick = onLockClick,
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier.testTag("safe_folder_lock_button")
                            ) {
                                Icon(Icons.Default.LockClock, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Lock now", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Info Banner
            Surface(
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    Text(
                        text = if (safeFiles.isEmpty()) {
                            "Files in Safe folder are stored privately in the app vault and protected by your PIN."
                        } else {
                            "Long-press any file to select, restore to Downloads, or permanently delete."
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            if (safeFiles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.FolderZip, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
                        }
                        Text("Safe folder is empty", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "Long-press files in your file browser and choose the Lock icon to move them to Safe folder.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 140.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(safeFiles, key = { it.id }) { safeFile ->
                        val isSelected = selectedSafeFiles.contains(safeFile)

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .combinedClickable(
                                    onClick = {
                                        if (isSelectionMode) {
                                            selectedSafeFiles = if (isSelected) selectedSafeFiles - safeFile else selectedSafeFiles + safeFile
                                        } else {
                                            scope.launch {
                                                // Vault files are encrypted; decrypt a temporary copy to open it.
                                                val vaultFile = resolveFile(safeFile)
                                                if (vaultFile != null) {
                                                    val typeInfo = MimeTypeDetector.detect(safeFile.originalName)
                                                    onPlayMedia(
                                                        MediaFile(
                                                            id = safeFile.id,
                                                            uri = Uri.fromFile(vaultFile),
                                                            name = safeFile.originalName,
                                                            duration = safeFile.duration,
                                                            size = safeFile.size,
                                                            mimeType = typeInfo.mimeType,
                                                            dateAdded = safeFile.addedAt,
                                                            isVideo = safeFile.mediaType == "video" || typeInfo.isVideo,
                                                            isAudio = safeFile.mediaType == "audio" || typeInfo.isAudio,
                                                            isImage = safeFile.mediaType == "image" || typeInfo.isImage,
                                                            isDocument = safeFile.mediaType == "document" || typeInfo.isDocument,
                                                            absolutePath = vaultFile.absolutePath
                                                        )
                                                    )
                                                } else {
                                                    Toast.makeText(context, "File missing from vault", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                    },
                                    onLongClick = {
                                        selectedSafeFiles = if (isSelected) selectedSafeFiles - safeFile else selectedSafeFiles + safeFile
                                    }
                                ),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            )
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val thumb by androidx.compose.runtime.produceState<File?>(null, safeFile.id) {
                                        // Only images get real thumbnails; decrypting whole videos for a grid would be far too slow.
                                        value = if (safeFile.mediaType == "image") resolveFile(safeFile) else null
                                    }
                                    if (safeFile.mediaType == "image" || safeFile.mediaType == "video") {
                                        if (thumb != null) {
                                            AsyncImage(
                                                model = thumb,
                                                contentDescription = safeFile.originalName,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        } else {
                                            Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainerHigh))
                                        }
                                        if (safeFile.mediaType == "video") {
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(CircleShape)
                                                    .background(Color.Black.copy(alpha = 0.6f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                                            }
                                        }
                                    } else {
                                        val accent = if (safeFile.mediaType == "audio") AccentAudio else AccentDoc
                                        Icon(
                                            imageVector = if (safeFile.mediaType == "audio") Icons.Default.AudioFile else Icons.Default.Description,
                                            contentDescription = safeFile.originalName,
                                            tint = accent,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }

                                    if (isSelected) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color.Black.copy(alpha = 0.3f)),
                                            contentAlignment = Alignment.TopEnd
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp))
                                        }
                                    }
                                }

                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text(
                                            text = safeFile.originalName,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = StorageUtils.formatSize(safeFile.size),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
