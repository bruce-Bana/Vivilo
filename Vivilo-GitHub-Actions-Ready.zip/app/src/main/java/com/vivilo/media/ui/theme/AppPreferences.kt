package com.vivilo.media.ui.theme

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.Color
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private val Context.viviloPrefsDataStore by preferencesDataStore(name = "vivilo_ui_preferences")

private object PrefKeys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val WALLPAPER = stringPreferencesKey("wallpaper")
    val TEXT_SCALE = stringPreferencesKey("text_scale")
    val HIGH_CONTRAST = booleanPreferencesKey("high_contrast")
    val LARGE_TOUCH_TARGETS = booleanPreferencesKey("large_touch_targets")
    val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
}

enum class AppThemeMode(val label: String) {
    SYSTEM("System default"),
    LIGHT("Light"),
    DARK("Dark"),
    AMOLED("AMOLED Black")
}

enum class WallpaperOption(
    val title: String,
    val description: String,
    val topColor: Color,
    val bottomColor: Color,
    val isGrid: Boolean = false
) {
    NONE(
        title = "Clean Minimal",
        description = "Standard clean appearance",
        topColor = Color.Transparent,
        bottomColor = Color.Transparent
    ),
    SAKURA_MIST(
        title = "Sakura Mist",
        description = "Soft pink & violet blossoms",
        topColor = Color(0xFF2E1A2E),
        bottomColor = Color(0xFF4A1942)
    ),
    MIDNIGHT_WAVE(
        title = "Midnight Wave",
        description = "Deep indigo & oceanic night",
        topColor = Color(0xFF0D1B2A),
        bottomColor = Color(0xFF1B263B)
    ),
    EMERALD_BREEZE(
        title = "Emerald Breeze",
        description = "Calm teal & forest mist",
        topColor = Color(0xFF0A2E36),
        bottomColor = Color(0xFF13505B)
    ),
    SUNSET_DUNES(
        title = "Sunset Dunes",
        description = "Warm amber & twilight horizon",
        topColor = Color(0xFF2C1320),
        bottomColor = Color(0xFF5F0F40)
    ),
    TECH_GRID(
        title = "Tech Grid",
        description = "Subtle cybernetic grid overlay",
        topColor = Color(0xFF101418),
        bottomColor = Color(0xFF1D242B),
        isGrid = true
    ),
    STARFIELD(
        title = "Starfield Nebula",
        description = "Cosmic blue & magenta aurora",
        topColor = Color(0xFF161233),
        bottomColor = Color(0xFF281C59)
    )
}

enum class AccessibilityTextScale(val scale: Float, val label: String) {
    STANDARD(1.0f, "Standard (100%)"),
    LARGE(1.15f, "Large (115%)"),
    EXTRA_LARGE(1.30f, "Extra Large (130%)")
}

data class AppPreferencesState(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val wallpaper: WallpaperOption = WallpaperOption.NONE,
    val textScale: AccessibilityTextScale = AccessibilityTextScale.STANDARD,
    val highContrast: Boolean = false,
    val largeTouchTargets: Boolean = false,
    val reduceMotion: Boolean = false
)

object AppPreferencesStore {
    fun preferencesFlow(context: Context): Flow<AppPreferencesState> {
        return context.applicationContext.viviloPrefsDataStore.data.map { prefs ->
            AppPreferencesState(
                themeMode = prefs[PrefKeys.THEME_MODE]?.let { name ->
                    AppThemeMode.entries.firstOrNull { it.name == name }
                } ?: AppThemeMode.SYSTEM,
                wallpaper = prefs[PrefKeys.WALLPAPER]?.let { name ->
                    WallpaperOption.entries.firstOrNull { it.name == name }
                } ?: WallpaperOption.NONE,
                textScale = prefs[PrefKeys.TEXT_SCALE]?.let { name ->
                    AccessibilityTextScale.entries.firstOrNull { it.name == name }
                } ?: AccessibilityTextScale.STANDARD,
                highContrast = prefs[PrefKeys.HIGH_CONTRAST] ?: false,
                largeTouchTargets = prefs[PrefKeys.LARGE_TOUCH_TARGETS] ?: false,
                reduceMotion = prefs[PrefKeys.REDUCE_MOTION] ?: false
            )
        }
    }

    suspend fun save(context: Context, state: AppPreferencesState) {
        context.applicationContext.viviloPrefsDataStore.edit { prefs ->
            prefs[PrefKeys.THEME_MODE] = state.themeMode.name
            prefs[PrefKeys.WALLPAPER] = state.wallpaper.name
            prefs[PrefKeys.TEXT_SCALE] = state.textScale.name
            prefs[PrefKeys.HIGH_CONTRAST] = state.highContrast
            prefs[PrefKeys.LARGE_TOUCH_TARGETS] = state.largeTouchTargets
            prefs[PrefKeys.REDUCE_MOTION] = state.reduceMotion
        }
    }
}

interface AppPreferencesController {
    fun updateThemeMode(mode: AppThemeMode)
    fun updateWallpaper(wallpaper: WallpaperOption)
    fun updateTextScale(scale: AccessibilityTextScale)
    fun toggleHighContrast()
    fun toggleLargeTouchTargets()
    fun toggleReduceMotion()
    fun resetToDefault()
}

val LocalAppPreferences = compositionLocalOf { AppPreferencesState() }
val LocalAppPreferencesController = compositionLocalOf<AppPreferencesController> {
    error("No AppPreferencesController provided")
}

@Composable
fun rememberAppPreferencesController(
    context: Context,
    state: AppPreferencesState,
    onStateChange: (AppPreferencesState) -> Unit
): AppPreferencesController {
    val scope = rememberCoroutineScope()
    return remember(state, context) {
        fun applyUpdate(newState: AppPreferencesState) {
            onStateChange(newState)
            scope.launch {
                AppPreferencesStore.save(context, newState)
            }
        }
        object : AppPreferencesController {
            override fun updateThemeMode(mode: AppThemeMode) {
                applyUpdate(state.copy(themeMode = mode))
            }

            override fun updateWallpaper(wallpaper: WallpaperOption) {
                applyUpdate(state.copy(wallpaper = wallpaper))
            }

            override fun updateTextScale(scale: AccessibilityTextScale) {
                applyUpdate(state.copy(textScale = scale))
            }

            override fun toggleHighContrast() {
                applyUpdate(state.copy(highContrast = !state.highContrast))
            }

            override fun toggleLargeTouchTargets() {
                applyUpdate(state.copy(largeTouchTargets = !state.largeTouchTargets))
            }

            override fun toggleReduceMotion() {
                applyUpdate(state.copy(reduceMotion = !state.reduceMotion))
            }

            override fun resetToDefault() {
                applyUpdate(AppPreferencesState())
            }
        }
    }
}
