package com.vivilo.media.ui.theme

import androidx.compose.ui.graphics.Color

// Light theme colors - Google Files / Material You inspired
val PrimaryBlue = Color(0xFF1B6EF3)
val PrimaryBlueDark = Color(0xFF0B57D0)
val SecondarySlate = Color(0xFF5E6E82)
val TertiaryTeal = Color(0xFF007B83)
val SurfaceLight = Color(0xFFF8FAFD)
val SurfaceVariantLight = Color(0xFFE9EEF6)

// Dark theme colors
val PrimaryBlueDarkTheme = Color(0xFFA8C7FA)
val SecondarySlateDark = Color(0xFFC2E7FF)
val TertiaryTealDark = Color(0xFF53DBCD)
val SurfaceDark = Color(0xFF101418)
val SurfaceVariantDark = Color(0xFF1D242B)

// Semantic media category accents
val AccentVideo = Color(0xFFEA4335)
val AccentAudio = Color(0xFF0097A7)
val AccentImage = Color(0xFF1B6EF3)
val AccentDoc = Color(0xFF673AB7)
val AccentFolder = Color(0xFFF9AB00)
val AccentStorage = Color(0xFF34A853)

