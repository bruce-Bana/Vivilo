package com.vivilo.media.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import androidx.compose.ui.unit.sp

// Every colour role is defined explicitly. Previously only a handful were set, so Material's
// baseline *purple* tones leaked into the blue palette (mini player, nav-bar indicator, the Clean
// banner, chips and dialogs all use the container roles).
private val DarkColorScheme =
    darkColorScheme(
        primary = PrimaryBlueDarkTheme,
        onPrimary = Color(0xFF062E6F),
        primaryContainer = Color(0xFF0842A0),
        onPrimaryContainer = Color(0xFFD3E3FD),
        secondary = SecondarySlateDark,
        onSecondary = Color(0xFF00344A),
        secondaryContainer = Color(0xFF0B4A6F),
        onSecondaryContainer = Color(0xFFC2E7FF),
        tertiary = TertiaryTealDark,
        onTertiary = Color(0xFF003733),
        tertiaryContainer = Color(0xFF00504A),
        onTertiaryContainer = Color(0xFF71F8E9),
        background = SurfaceDark,
        onBackground = Color(0xFFE2E6EC),
        surface = SurfaceDark,
        onSurface = Color(0xFFE2E6EC),
        surfaceVariant = SurfaceVariantDark,
        onSurfaceVariant = Color(0xFFC3C8D0),
        outline = Color(0xFF8C9199),
        outlineVariant = Color(0xFF41474F),
        surfaceContainerLowest = Color(0xFF0B0E12),
        surfaceContainerLow = Color(0xFF161B21),
        surfaceContainer = Color(0xFF1A2027),
        surfaceContainerHigh = Color(0xFF242B33),
        surfaceContainerHighest = Color(0xFF2F363F)
    )

private val AmoledColorScheme =
    DarkColorScheme.copy(
        background = Color(0xFF000000),
        surface = Color(0xFF0A0A0A),
        surfaceVariant = Color(0xFF141414),
        surfaceContainerLowest = Color(0xFF000000),
        surfaceContainerLow = Color(0xFF0A0A0A),
        surfaceContainer = Color(0xFF111111),
        surfaceContainerHigh = Color(0xFF1A1A1A),
        surfaceContainerHighest = Color(0xFF242424)
    )

private val LightColorScheme =
    lightColorScheme(
        primary = PrimaryBlue,
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFD6E4FF),
        onPrimaryContainer = Color(0xFF041E49),
        secondary = SecondarySlate,
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFDCE3EE),
        onSecondaryContainer = Color(0xFF1A2431),
        tertiary = TertiaryTeal,
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFBFEEF0),
        onTertiaryContainer = Color(0xFF002022),
        background = SurfaceLight,
        onBackground = Color(0xFF191C20),
        surface = SurfaceLight,
        onSurface = Color(0xFF191C20),
        surfaceVariant = SurfaceVariantLight,
        onSurfaceVariant = Color(0xFF44474E),
        outline = Color(0xFF74777F),
        outlineVariant = Color(0xFFC4C6D0),
        surfaceContainerLowest = Color(0xFFFFFFFF),
        surfaceContainerLow = Color(0xFFF2F5FA),
        surfaceContainer = Color(0xFFEDF1F7),
        surfaceContainerHigh = Color(0xFFE7ECF3),
        surfaceContainerHighest = Color(0xFFE1E6EE)
    )

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun ViviloTheme(
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    // Read the saved preferences once, synchronously, so the very first frame already uses the
    // user's theme. With a default initial value the app flashed the system theme, then switched.
    val initialPrefs = remember(context) {
        runCatching { runBlocking { AppPreferencesStore.preferencesFlow(context).first() } }
            .getOrDefault(AppPreferencesState())
    }
    val persistedPrefs by remember(context) {
        AppPreferencesStore.preferencesFlow(context)
    }.collectAsState(initial = initialPrefs)

    var prefs by remember { mutableStateOf(initialPrefs) }
    LaunchedEffect(persistedPrefs) {
        prefs = persistedPrefs
    }

    val controller = rememberAppPreferencesController(
        context = context,
        state = prefs,
        onStateChange = { prefs = it }
    )

    val systemDark = isSystemInDarkTheme()
    // Every wallpaper is a dark gradient. Drawing the light scheme's dark text on top of it made
    // the whole UI unreadable, so choosing a wallpaper switches to the dark scheme.
    val wallpaperActive = prefs.wallpaper != WallpaperOption.NONE
    val isDark = wallpaperActive || when (prefs.themeMode) {
        AppThemeMode.SYSTEM -> systemDark
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.AMOLED -> true
    }

    val baseScheme = when {
        prefs.themeMode == AppThemeMode.AMOLED -> AmoledColorScheme
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        isDark -> DarkColorScheme
        else -> LightColorScheme
    }

    val colorScheme = if (prefs.highContrast) {
        baseScheme.copy(
            primary = if (isDark) Color(0xFF8AB4F8) else Color(0xFF0B57D0),
            outline = if (isDark) Color(0xFFE8EAED) else Color(0xFF202124),
            outlineVariant = if (isDark) Color(0xFFBDC1C6) else Color(0xFF5F6368)
        )
    } else {
        baseScheme
    }

    val scale = prefs.textScale.scale
    val scaledTypography = Typography.copy(
        titleLarge = Typography.titleLarge.copy(fontSize = (22 * scale).sp, lineHeight = (28 * scale).sp),
        titleMedium = Typography.titleMedium.copy(fontSize = (16 * scale).sp, lineHeight = (22 * scale).sp),
        titleSmall = Typography.titleSmall.copy(fontSize = (14 * scale).sp, lineHeight = (20 * scale).sp),
        bodyLarge = Typography.bodyLarge.copy(fontSize = (16 * scale).sp, lineHeight = (24 * scale).sp),
        bodyMedium = Typography.bodyMedium.copy(fontSize = (14 * scale).sp, lineHeight = (20 * scale).sp),
        bodySmall = Typography.bodySmall.copy(fontSize = (12 * scale).sp, lineHeight = (16 * scale).sp),
        labelLarge = Typography.labelLarge.copy(fontSize = (14 * scale).sp, lineHeight = (20 * scale).sp),
        labelMedium = Typography.labelMedium.copy(fontSize = (12 * scale).sp, lineHeight = (16 * scale).sp),
        labelSmall = Typography.labelSmall.copy(fontSize = (11 * scale).sp, lineHeight = (16 * scale).sp)
    )

    // enableEdgeToEdge() picks status/navigation icon colours from the *system* theme. When the
    // in-app theme differs (e.g. Light app on a dark phone) the icons became invisible.
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !isDark
            controller.isAppearanceLightNavigationBars = !isDark
        }
    }

    CompositionLocalProvider(
        LocalAppPreferences provides prefs,
        LocalAppPreferencesController provides controller
    ) {
        MaterialTheme(colorScheme = colorScheme, typography = scaledTypography, content = content)
    }
}
