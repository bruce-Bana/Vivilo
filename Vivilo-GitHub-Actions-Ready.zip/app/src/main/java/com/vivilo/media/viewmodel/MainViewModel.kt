package com.vivilo.media.viewmodel

import android.app.Application
import android.database.ContentObserver
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vivilo.media.data.MediaFile
import com.vivilo.media.data.MediaRepository
import com.vivilo.media.data.SafeFolderManager
import com.vivilo.media.data.SafeMoveResult
import com.vivilo.media.data.StorageScanInfo
import com.vivilo.media.data.StorageUtils
import com.vivilo.media.data.db.FavoriteEntity
import com.vivilo.media.data.db.PlaybackHistoryEntity
import com.vivilo.media.data.db.PlaylistEntity
import com.vivilo.media.data.db.PlaylistItemEntity
import com.vivilo.media.data.db.SafeFileEntity
import com.vivilo.media.data.db.SearchHistoryEntity
import com.vivilo.media.data.db.ViviloDatabase
import com.vivilo.media.data.db.ViviloMediaDatabaseRepository
import com.vivilo.media.service.PlaybackManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MediaRepository(application)
    val dbRepo = ViviloMediaDatabaseRepository(ViviloDatabase.getDatabase(application).dao())
    val playbackManager = PlaybackManager.getInstance(application)
    val safeFolderManager = SafeFolderManager(application, dbRepo)

    private val _mediaFiles = MutableStateFlow<List<MediaFile>>(emptyList())
    val mediaFiles: StateFlow<List<MediaFile>> = _mediaFiles.asStateFlow()

    private val _storageFiles = MutableStateFlow<List<MediaFile>>(emptyList())
    val storageFiles: StateFlow<List<MediaFile>> = _storageFiles.asStateFlow()

    private val _currentPath = MutableStateFlow<String?>(null)
    val currentPath: StateFlow<String?> = _currentPath.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Currently viewed/opened file metadata (preserves exact name/type for MediaStore & Vault URIs)
    private val _activeViewerFile = MutableStateFlow<MediaFile?>(null)
    val activeViewerFile: StateFlow<MediaFile?> = _activeViewerFile.asStateFlow()

    private val _activeViewerQueue = MutableStateFlow<List<MediaFile>>(emptyList())
    val activeViewerQueue: StateFlow<List<MediaFile>> = _activeViewerQueue.asStateFlow()

    // Real-time Storage Stats
    private val _storageScanInfo = MutableStateFlow(StorageUtils.getQuickStorageInfo())
    val storageScanInfo: StateFlow<StorageScanInfo> = _storageScanInfo.asStateFlow()

    // Safe Folder State
    val safeFiles: StateFlow<List<SafeFileEntity>> = dbRepo.safeFiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isSafeFolderUnlocked = MutableStateFlow(false)
    val isSafeFolderUnlocked: StateFlow<Boolean> = _isSafeFolderUnlocked.asStateFlow()

    private val _isSafeFolderPinSet = MutableStateFlow(safeFolderManager.isPinSet())
    val isSafeFolderPinSet: StateFlow<Boolean> = _isSafeFolderPinSet.asStateFlow()

    val playlists: StateFlow<List<PlaylistEntity>> = dbRepo.playlists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<FavoriteEntity>> = dbRepo.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<PlaybackHistoryEntity>> = dbRepo.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentSearches: StateFlow<List<SearchHistoryEntity>> = dbRepo.recentSearches
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selection mode for batch operations
    private val _selectedFiles = MutableStateFlow<Set<MediaFile>>(emptySet())
    val selectedFiles: StateFlow<Set<MediaFile>> = _selectedFiles.asStateFlow()

    private val _isSelectionMode = MutableStateFlow(false)
    val isSelectionMode: StateFlow<Boolean> = _isSelectionMode.asStateFlow()

    // ContentObserver for live MediaStore auto-refresh
    // MediaStore fires a burst of change notifications (one per row) for a single copy/scan, so
    // reloads are debounced instead of re-querying the whole library for every notification.
    private var observerReloadJob: Job? = null
    private val mediaContentObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            super.onChange(selfChange)
            observerReloadJob?.cancel()
            observerReloadJob = viewModelScope.launch {
                delay(700L)
                loadMediaFiles()
            }
        }
    }

    private var loadJob: Job? = null

    init {
        try {
            val resolver = application.contentResolver
            resolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, mediaContentObserver)
            resolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, mediaContentObserver)
            resolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaContentObserver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        loadMediaFiles()
    }

    fun loadMediaFiles() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _isLoading.value = true
            try {
                val files = repository.getMediaFiles()
                _mediaFiles.value = files
                _storageScanInfo.value = withContext(Dispatchers.IO) {
                    StorageUtils.getStorageInfo(getApplication(), files)
                }
                _isLoading.value = false
            } catch (e: CancellationException) {
                // A newer load replaced this one; it owns the loading flag now.
                throw e
            } catch (e: Exception) {
                _isLoading.value = false
            }
        }
    }

    fun loadStorageFiles(path: String? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            val targetPath = path ?: Environment.getExternalStorageDirectory().absolutePath
            _currentPath.value = targetPath
            _storageFiles.value = repository.getStorageFiles(targetPath)
            _isLoading.value = false
        }
    }

    fun navigateUp() {
        val current = _currentPath.value ?: return
        val parent = File(current).parent
        val root = Environment.getExternalStorageDirectory().absolutePath
        if (parent != null && current != root) {
            loadStorageFiles(parent)
        }
    }

    // Selection mode
    fun toggleFileSelection(file: MediaFile) {
        if (file.isDirectory) return
        val current = _selectedFiles.value.toMutableSet()
        if (current.contains(file)) {
            current.remove(file)
        } else {
            current.add(file)
        }
        _selectedFiles.value = current
        _isSelectionMode.value = current.isNotEmpty()
    }

    fun selectAll(files: List<MediaFile>) {
        val all = files.filter { !it.isDirectory }.toSet()
        _selectedFiles.value = all
        _isSelectionMode.value = all.isNotEmpty()
    }

    /** Deletes app-reachable files directly (file:// entries); returns the content URIs that need a system dialog. */
    fun deleteDirectFiles(files: List<MediaFile>, onComplete: (deleted: Int, needsApproval: List<android.net.Uri>) -> Unit) {
        viewModelScope.launch {
            val approval = ArrayList<android.net.Uri>()
            var deleted = 0
            withContext(Dispatchers.IO) {
                for (f in files) {
                    val path = f.absolutePath
                    if (!path.isNullOrEmpty()) {
                        if (File(path).delete()) deleted++
                    } else if (f.uri.scheme == "content") {
                        val ok = try { getApplication<Application>().contentResolver.delete(f.uri, null, null) > 0 } catch (_: Exception) { false }
                        if (ok) deleted++ else approval += f.uri
                    }
                }
            }
            clearSelection()
            onComplete(deleted, approval)
        }
    }

    fun clearSelection() {
        _selectedFiles.value = emptySet()
        _isSelectionMode.value = false
    }

    // Viewer & Playback actions
    fun openMediaFile(file: MediaFile, queue: List<MediaFile> = emptyList()) {
        _activeViewerFile.value = file
        _activeViewerQueue.value = queue
        // Re-opening what is already playing (e.g. tapping the mini player) must not restart it.
        if ((file.isVideo || file.isAudio) && !playbackManager.isActivelyLoaded(file)) {
            playbackManager.playFile(file, queue)
        }
    }

    fun resolveMediaFile(uriString: String): MediaFile? {
        val active = _activeViewerFile.value
        if (active != null && active.uri.toString() == uriString) return active
        return _mediaFiles.value.firstOrNull { it.uri.toString() == uriString }
            ?: _storageFiles.value.firstOrNull { it.uri.toString() == uriString }
            ?: playbackManager.currentFile.value?.takeIf { it.uri.toString() == uriString }
    }

    // Playlist actions
    fun createPlaylist(name: String, addSelectedFiles: Boolean = false, onCreated: ((Long) -> Unit)? = null) {
        viewModelScope.launch {
            val id = dbRepo.createPlaylist(name)
            if (addSelectedFiles && _selectedFiles.value.isNotEmpty()) {
                addFilesToPlaylistInternal(id, _selectedFiles.value.toList())
                clearSelection()
            }
            onCreated?.invoke(id)
        }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch {
            dbRepo.deletePlaylist(id)
        }
    }

    fun getPlaylistItems(playlistId: Long): Flow<List<PlaylistItemEntity>> {
        return dbRepo.getPlaylistItems(playlistId)
    }

    fun removeFromPlaylist(itemId: Long) {
        viewModelScope.launch {
            dbRepo.removeFromPlaylist(itemId)
        }
    }

    fun addSelectedToPlaylist(playlistId: Long) {
        viewModelScope.launch {
            addFilesToPlaylistInternal(playlistId, _selectedFiles.value.toList())
            clearSelection()
        }
    }

    private suspend fun addFilesToPlaylistInternal(playlistId: Long, files: List<MediaFile>) {
        files.forEach { file ->
            dbRepo.addToPlaylist(
                playlistId = playlistId,
                uriString = file.uri.toString(),
                name = file.name,
                mediaType = when {
                    file.isVideo -> "video"
                    file.isAudio -> "audio"
                    file.isImage -> "image"
                    file.isDocument -> "document"
                    else -> "other"
                },
                duration = file.duration,
                size = file.size
            )
        }
    }

    fun toggleFavorite(file: MediaFile, currentIsFav: Boolean) {
        viewModelScope.launch {
            dbRepo.toggleFavorite(
                uriString = file.uri.toString(),
                name = file.name,
                mediaType = when {
                    file.isVideo -> "video"
                    file.isAudio -> "audio"
                    file.isImage -> "image"
                    file.isDocument -> "document"
                    else -> "other"
                },
                duration = file.duration,
                size = file.size,
                isFav = currentIsFav
            )
        }
    }

    fun removeFavorite(uriString: String) {
        viewModelScope.launch {
            dbRepo.toggleFavorite(uriString, "", "", 0L, 0L, isFav = true)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            dbRepo.clearHistory()
        }
    }

    fun saveSearchQuery(query: String) {
        viewModelScope.launch {
            dbRepo.saveSearchQuery(query)
        }
    }

    fun deleteSearchQuery(query: String) {
        viewModelScope.launch {
            dbRepo.deleteSearchQuery(query)
        }
    }

    fun playMediaFile(file: MediaFile, queue: List<MediaFile> = emptyList()) {
        _activeViewerFile.value = file
        _activeViewerQueue.value = queue
        playbackManager.playFile(file, queue)
    }

    // Safe Folder Operations
    fun setSafeFolderPin(pin: String): Boolean {
        val success = safeFolderManager.setPin(pin)
        if (success) {
            _isSafeFolderPinSet.value = true
            _isSafeFolderUnlocked.value = true
        }
        return success
    }

    /** Remaining lock-out time in ms after too many wrong PIN attempts (0 when not locked out). */
    fun safeFolderLockoutRemainingMs(): Long = safeFolderManager.lockoutRemainingMs()

    fun unlockSafeFolder(pin: String): Boolean {
        val verified = safeFolderManager.verifyPin(pin)
        if (verified) {
            _isSafeFolderUnlocked.value = true
        }
        return verified
    }

    fun changeSafeFolderPin(oldPin: String, newPin: String): Boolean {
        return safeFolderManager.changePin(oldPin, newPin)
    }

    fun lockSafeFolder() {
        _isSafeFolderUnlocked.value = false
        safeFolderManager.clearDecryptedCache()
    }

    fun moveToSafeFolder(files: List<MediaFile>, onComplete: (SafeMoveResult) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = safeFolderManager.moveToSafeFolder(files)
            clearSelection()
            loadMediaFiles()
            _isLoading.value = false
            onComplete(result)
        }
    }

    fun moveOutOfSafeFolder(safeFiles: List<SafeFileEntity>, onComplete: (Int) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val count = safeFolderManager.moveOutOfSafeFolder(safeFiles)
            loadMediaFiles()
            _isLoading.value = false
            onComplete(count)
        }
    }

    fun deleteSafeFilePermanently(safeFile: SafeFileEntity) {
        viewModelScope.launch {
            try {
                val vaultFile = safeFolderManager.getVaultFile(safeFile.safeVaultFileName)
                if (vaultFile.exists()) vaultFile.delete()
                dbRepo.removeSafeFile(safeFile.id)
                refreshStorageInfo()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun clearJunkCache(onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val cleared = withContext(Dispatchers.IO) {
                StorageUtils.clearAppCache(getApplication())
            }
            refreshStorageInfo()
            onComplete(cleared)
        }
    }

    fun refreshStorageInfo() {
        viewModelScope.launch {
            _storageScanInfo.value = withContext(Dispatchers.IO) {
                StorageUtils.getStorageInfo(getApplication(), _mediaFiles.value)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        safeFolderManager.clearDecryptedCache()
        try {
            getApplication<Application>().contentResolver.unregisterContentObserver(mediaContentObserver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
