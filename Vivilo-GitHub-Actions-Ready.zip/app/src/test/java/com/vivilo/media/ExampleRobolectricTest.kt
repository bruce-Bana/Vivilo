package com.vivilo.media

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.vivilo.media.data.MediaFile
import com.vivilo.media.data.MimeTypeDetector
import com.vivilo.media.data.SafeFolderManager
import com.vivilo.media.data.StorageUtils
import com.vivilo.media.data.db.ViviloDatabase
import com.vivilo.media.data.db.ViviloMediaDatabaseRepository
import com.vivilo.media.ui.screens.formatDuration
import java.security.MessageDigest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Vivilo", appName)
    }

    @Test
    fun `mime type detector handles extended audio video image and document formats`() {
        val flac = MimeTypeDetector.detect("track.FLAC")
        assertTrue(flac.isAudio)
        assertFalse(flac.isVideo)
        assertFalse(flac.isDocument)
        assertEquals("audio/flac", flac.mimeType)

        val mkv = MimeTypeDetector.detect("movie.mkv")
        assertTrue(mkv.isVideo)
        assertFalse(mkv.isAudio)
        assertEquals("video/mkv", mkv.mimeType)

        val heic = MimeTypeDetector.detect("photo.heic")
        assertTrue(heic.isImage)
        assertFalse(heic.isVideo)

        val pdf = MimeTypeDetector.detect("manual.pdf")
        assertTrue(pdf.isDocument)
        assertEquals("application/pdf", pdf.mimeType)
    }

    @Test
    fun `storage utils formats sizes and finds duplicate candidates`() {
        assertEquals("0 B", StorageUtils.formatSize(0L))
        assertEquals("1.0 KB", StorageUtils.formatSize(1024L))
        assertEquals("1.5 MB", StorageUtils.formatSize(1536L * 1024L))

        val files = listOf(
            MediaFile(1L, Uri.parse("content://media/1"), "Clip.mp4", 1000L, 5_000_000L, "video/mp4", 0L, isVideo = true, isAudio = false, isImage = false, isDocument = false),
            MediaFile(2L, Uri.parse("content://media/2"), "clip.mp4", 1000L, 5_000_000L, "video/mp4", 0L, isVideo = true, isAudio = false, isImage = false, isDocument = false),
            MediaFile(3L, Uri.parse("content://media/3"), "unique.mp3", 1000L, 3_000_000L, "audio/mpeg", 0L, isVideo = false, isAudio = true, isImage = false, isDocument = false)
        )
        val duplicates = StorageUtils.findDuplicateGroups(files)
        assertEquals(1, duplicates.size)
        assertEquals(2, duplicates.first().size)
    }

    @Test
    fun `safe folder pin lifecycle validates and updates pin`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ViviloDatabase.getDatabase(context)
        val manager = SafeFolderManager(context, ViviloMediaDatabaseRepository(db.dao()))
        manager.resetSafeFolder()

        assertFalse(manager.isPinSet())
        assertFalse(manager.setPin("12"))
        assertFalse(manager.setPin("abcd"))
        assertTrue(manager.setPin("1357"))
        assertTrue(manager.isPinSet())
        assertTrue(manager.verifyPin("1357"))
        assertFalse(manager.verifyPin("0000"))

        assertFalse(manager.changePin("0000", "2468"))
        assertTrue(manager.changePin("1357", "2468"))
        assertTrue(manager.verifyPin("2468"))
        assertFalse(manager.verifyPin("1357"))
    }

    @Test
    fun `format duration renders mm_ss and h_mm_ss`() {
        assertEquals("00:00", formatDuration(0L))
        assertEquals("01:05", formatDuration(65_000L))
        assertEquals("1:01:01", formatDuration(3_661_000L))
    }
    @Test
    fun `safe folder locks out after repeated wrong pins`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = SafeFolderManager(context, ViviloMediaDatabaseRepository(ViviloDatabase.getDatabase(context).dao()))
        manager.resetSafeFolder()
        assertTrue(manager.setPin("1357"))

        repeat(5) { assertFalse(manager.verifyPin("0000")) }

        assertTrue(manager.lockoutRemainingMs() > 0L)
        // While locked out even the correct PIN is refused.
        assertFalse(manager.verifyPin("1357"))
    }

    @Test
    fun `legacy unsalted pin is accepted once and upgraded to a salted hash`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = SafeFolderManager(context, ViviloMediaDatabaseRepository(ViviloDatabase.getDatabase(context).dao()))
        manager.resetSafeFolder()

        val prefs = context.getSharedPreferences("vivilo_safe_folder_prefs", Context.MODE_PRIVATE)
        val legacyHash = MessageDigest.getInstance("SHA-256")
            .digest("2468".toByteArray())
            .joinToString("") { "%02x".format(it) }
        prefs.edit().putString("safe_pin_hash", legacyHash).commit()

        assertTrue(manager.verifyPin("2468"))
        assertTrue(prefs.contains("safe_pin_salt"))
        assertTrue(manager.verifyPin("2468"))
        assertFalse(manager.verifyPin("1111"))
    }

    @Test
    fun `quick storage info never reports invented numbers`() {
        val info = StorageUtils.getQuickStorageInfo()
        assertEquals(0L, info.cleanableJunkBytes)
        assertEquals(0, info.duplicateCandidatesCount)
    }
}
